# Phishing URL Checker - Integrasi PHP, Python, dan MySQL

## Struktur
- PHP: Frontend, login, registrasi, riwayat, admin
- Python: Deteksi phishing (phishing_detection.py)
- MySQL: Menyimpan user & riwayat

## Setup
1. **Database**
   - Buat database: `phishingdetect`
   - Import tabel:
     ```sql
     CREATE TABLE users (
       id INT AUTO_INCREMENT PRIMARY KEY,
       username VARCHAR(50) NOT NULL,
       password VARCHAR(255) NOT NULL,
       role ENUM('user','admin') DEFAULT 'user'
     );
     CREATE TABLE riwayat (
       id INT AUTO_INCREMENT PRIMARY KEY,
       user_id INT,
       url VARCHAR(255),
       hasil VARCHAR(50),
       waktu DATETIME DEFAULT CURRENT_TIMESTAMP,
       FOREIGN KEY (user_id) REFERENCES users(id)
     );
     ```
2. **Konfigurasi**
   - Edit `config.php` jika user/password database berbeda
3. **Jalankan**
   - Pastikan Python & dependensi sudah terinstall (`phishing_detection.py` bisa dijalankan manual)
   - Jalankan XAMPP/Apache, akses via browser

## Catatan
- Untuk deteksi, PHP memanggil Python: `shell_exec('python phishing_detection.py <url>')`
- Semua fitur deteksi & riwayat hanya untuk user login
- Admin bisa melihat semua user & riwayat
- Desain mengikuti referensi, navbar dinamis 