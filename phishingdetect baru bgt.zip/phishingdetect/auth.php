<?php
session_start();
require 'config.php';
$active_tab = isset($_GET['tab']) && $_GET['tab'] === 'register' ? 'register' : 'login';
$msg_login = '';
$msg_register = '';
$flash = '';
if (isset($_SESSION['flash_msg'])) {
    $flash = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}
// Proses login (username/email + password)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $active_tab = 'login';
    $username = trim($conn->real_escape_string($_POST['username']));
    $email = trim($conn->real_escape_string($_POST['email']));
    $password = $_POST['password'];
    if (empty($username) || empty($email) || empty($password)) {
        $msg_login = 'Semua field wajib diisi!';
    } else {
        $result = $conn->query("SELECT * FROM users WHERE username='$username' AND email='$email'");
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = isset($user['id_users']) ? $user['id_users'] : null;
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['flash_msg'] = 'Berhasil masuk sebagai ' . htmlspecialchars($user['username']) . '!';
                if ($user['role'] === 'admin') {
                    header('Location: admin.php');
                } else {
                    header('Location: index.php');
                }
                exit();
            } else {
                $msg_login = 'Password salah!';
            }
        } else {
            $msg_login = 'Username dan email tidak cocok!';
        }
    }
}
// Proses registrasi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $active_tab = 'register';
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'user';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg_register = 'Format email tidak valid!';
    } else {
        $cek = $conn->query("SELECT id_users FROM users WHERE username='$username' OR email='$email'");
        if ($cek->num_rows > 0) {
            $msg_register = 'Username atau email sudah terdaftar!';
        } else {
            $conn->query("INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', '$role')");
            $_SESSION['flash_msg'] = 'Akun berhasil dibuat! Silakan login.';
            header('Location: auth.php?tab=login');
            exit();
        }
    }
}
// Ambil riwayat user jika login
$riwayat = [];
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    try {
        $stmt = $conn->prepare("SELECT * FROM riwayat WHERE username=? ORDER BY waktu DESC LIMIT 5");
        if ($stmt) {
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $result = $stmt->get_result();
            while($row = $result->fetch_assoc()) {
                $riwayat[] = $row;
            }
        }
    } catch (Exception $e) {
        // Jika ada error database, set riwayat kosong
        $riwayat = [];
        error_log("Database error in auth.php: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login/Register - PhishingDetect</title>
    <link rel="stylesheet" href="static/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
    /* Style khusus untuk subtitle di halaman login */
    header p.login-subtitle {
        color: #fff !important;
        text-shadow: 0 2px 8px rgba(0,0,0,0.3);
        background: rgba(0,0,0,0.2);
        padding: 8px 16px;
        border-radius: 20px;
        display: inline-block;
        backdrop-filter: blur(10px);
        font-weight: 500;
    }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <header class="animate__animated animate__fadeIn">
        <h1>Login & Registrasi</h1>
        <p class="login-subtitle">Masuk ke akun Anda atau daftar untuk mulai menggunakan PhishingDetect</p>
    </header>
<div class="container">
    <div class="card animate__animated animate__fadeInUp" style="max-width:430px;margin:40px auto;">
        <div style="display:flex;justify-content:center;gap:10px;margin-bottom:18px;">
            <button onclick="showTab('login')" class="btn-animated" id="tab-login" style="<?= $active_tab=='login'?'background:#2563eb;color:#fff;':'background:#e0e7ef;color:#2563eb;' ?>;width:48%;font-weight:bold;">Login</button>
            <button onclick="showTab('register')" class="btn-animated" id="tab-register" style="<?= $active_tab=='register'?'background:#2563eb;color:#fff;':'background:#e0e7ef;color:#2563eb;' ?>;width:48%;font-weight:bold;">Registrasi</button>
        </div>
        <?php if ($flash): ?>
            <div class="result-box safe animate__animated animate__fadeInDown" style="margin-bottom:16px;"> <?= htmlspecialchars($flash) ?> </div>
        <?php endif; ?>
        <div id="form-login" style="display:<?= $active_tab=='login'?'block':'none' ?>;">
            <h2 style="text-align:center;color:#2563eb;"><i class="fas fa-sign-in-alt"></i> Login</h2>
            <?php if ($msg_login): ?>
                <div class="result-box phishing" style="margin-bottom:16px;"> <?= htmlspecialchars($msg_login) ?> </div>
            <?php endif; ?>
            <form method="post">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Username</label>
                    <input type="text" name="username" id="username" class="pulse-focus" placeholder="Username" style="width:100%;margin-bottom:12px;">
                </div>
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" name="email" id="email" class="pulse-focus" placeholder="Email" style="width:100%;margin-bottom:12px;">
                </div>
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" id="password" class="pulse-focus" required placeholder="Password" style="width:100%;margin-bottom:18px;">
                </div>
                <button type="submit" name="login" class="btn-animated" style="width:100%;">Login</button>
            </form>
            <div style="font-size:0.95em;color:#888;margin-top:8px;">Semua field wajib diisi!</div>
        </div>
        <div id="form-register" style="display:<?= $active_tab=='register'?'block':'none' ?>;">
            <h2 style="text-align:center;color:#2563eb;"><i class="fas fa-user-plus"></i> Registrasi</h2>
            <?php if ($msg_register): ?>
                <div class="result-box <?= strpos($msg_register,'berhasil')!==false?'safe':'phishing' ?>" style="margin-bottom:16px;"> <?= htmlspecialchars($msg_register) ?> </div>
            <?php endif; ?>
            <form method="post">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Username</label>
                    <input type="text" name="username" id="username" class="pulse-focus" required placeholder="Username" style="width:100%;margin-bottom:12px;">
                </div>
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" name="email" id="email" class="pulse-focus" required placeholder="Email" style="width:100%;margin-bottom:12px;">
                </div>
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" id="password" class="pulse-focus" required placeholder="Password" style="width:100%;margin-bottom:18px;">
                </div>
                <button type="submit" name="register" class="btn-animated" style="width:100%;">Daftar</button>
            </form>
        </div>
    </div>
    <?php if (isset($_SESSION['username'])): ?>
    <div class="card animate__animated animate__fadeInUp" style="max-width:430px;margin:24px auto 0 auto;">
        <h3 style="color:#2563eb;text-align:center;"><i class="fas fa-history"></i> Riwayat Pencarian Anda</h3>
        <ul class="history-list" id="history-list">
          <?php if ($riwayat): foreach ($riwayat as $item): ?>
            <li class="history-item animate__animated animate__fadeInRight">
              <span class="history-url"><?= htmlspecialchars($item['url']) ?></span>
              <span class="history-result <?= strtolower($item['hasil'])=="bukan website phishing" ? 'safe' : 'phishing' ?>">
                <?= htmlspecialchars($item['hasil']) ?>
              </span>
            </li>
          <?php endforeach; else: ?>
            <li class="history-item">No history yet</li>
          <?php endif; ?>
        </ul>
    </div>
    <?php endif; ?>
</div>

<footer>
    <div class="footer-content">
        <div class="creator-info animate__animated animate__fadeIn">
            <p>Created by <span class="author-name">Laurensius Alessandro</span></p>
        </div>
        <div class="social-icons animate__animated animate__fadeIn">
            <a href="https://instagram.com/laurenaldr" target="_blank" class="social-icon">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:laurensandro9@gmail.com" class="social-icon">
                <i class="far fa-envelope"></i>
            </a>
            <a href="https://github.com/Laurenwork" target="_blank" class="social-icon">
                <i class="fab fa-github"></i>
            </a>
            <a href="https://www.linkedin.com/in/laurensius-alessandro/" target="_blank" class="social-icon">
                <i class="fab fa-linkedin"></i>
            </a>
        </div>
        <p class="copyright">&copy; 2025 URL Phishing Detection. All rights reserved.</p>
    </div>
</footer>

<script>
function showTab(tab) {
    document.getElementById('form-login').style.display = tab === 'login' ? 'block' : 'none';
    document.getElementById('form-register').style.display = tab === 'register' ? 'block' : 'none';
    document.getElementById('tab-login').style.background = tab === 'login' ? '#2563eb' : '#e0e7ef';
    document.getElementById('tab-login').style.color = tab === 'login' ? '#fff' : '#2563eb';
    document.getElementById('tab-register').style.background = tab === 'register' ? '#2563eb' : '#e0e7ef';
    document.getElementById('tab-register').style.color = tab === 'register' ? '#fff' : '#2563eb';
}
</script>

<script src="static/theme.js"></script>
<script>
    // Debug: Check if theme.js loaded
    console.log('Auth page loaded');
    if (typeof window.themeManager !== 'undefined') {
        console.log('Theme manager is available');
    } else {
        console.log('Theme manager not found');
    }
</script>
</body>
</html> 