# Setup Admin Panel - PhishingDetect

## Cara Menambahkan Kolom Email ke Database

Jika database sudah ada tanpa kolom email, ikuti langkah berikut:

### 1. Melalui phpMyAdmin:

1. Buka `http://localhost/phpmyadmin`
2. Pilih database `phishingdetect`
3. Klik tab "SQL"
4. Jalankan query:

```sql
ALTER TABLE users ADD COLUMN email VARCHAR(100) NOT NULL DEFAULT 'user@example.com' AFTER username;
```

### 2. Atau gunakan file `add_email_column.sql`:

1. Buka phpMyAdmin
2. Pilih database `phishingdetect`
3. Klik tab "SQL"
4. Copy dan paste isi file `add_email_column.sql`

## Cara Membuat User Menjadi Admin

### Melalui phpMyAdmin:

1. Buka `http://localhost/phpmyadmin`
2. Pilih database `phishingdetect`
3. Klik tabel `users`
4. Klik "Edit" pada user yang ingin dijadikan admin
5. Ubah kolom `role` dari `user` menjadi `admin`
6. Klik "Go"

### Melalui SQL Query:

```sql
UPDATE users SET role = 'admin' WHERE username = 'username_yang_diinginkan';
```

## Fitur Admin Panel

### 1. Dashboard Statistik:

- Total Users
- Total Deteksi
- Admin Users
- Deteksi Hari Ini

### 2. Manajemen User:

- Lihat semua user terdaftar
- Lihat email dan role user
- Lihat jumlah deteksi per user
- Hapus user (termasuk semua riwayatnya)

### 3. Manajemen Riwayat:

- Lihat semua riwayat deteksi
- Tampilkan waktu deteksi (tanggal dan jam)
- Tampilkan hasil dengan warna (merah=phishing, hijau=aman)

- Hapus riwayat individual

### 4. Keamanan:

- Hanya admin yang bisa akses
- Konfirmasi sebelum menghapus
- Admin tidak bisa menghapus dirinya sendiri

## Akses Admin Panel

1. Login dengan akun yang sudah dijadikan admin
2. Klik "Admin Panel" di navbar
3. Atau akses langsung: `http://localhost/Phishingdetect/admin.php`
