#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
IMPLEMENTASI DECISION TREE KLASIFIKASI DAN BAGGING
PHISHING DETECTION SYSTEM
===============================================================================

File ini berisi implementasi lengkap Decision Tree dan Bagging untuk
sistem deteksi phishing dengan contoh code yang bisa dijalankan.

Author: AI Assistant
Date: 2025-01-27
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.tree import plot_tree
import joblib
import warnings
warnings.filterwarnings('ignore')

# Set style untuk plot
plt.style.use('default')
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 10

class PhishingDetectionSystem:
    """
    Sistem deteksi phishing menggunakan Decision Tree + Bagging
    """
    
    def __init__(self, random_state=42):
        """
        Inisialisasi sistem deteksi phishing
        
        Parameters:
        -----------
        random_state : int
            Random state untuk reproducibility
        """
        self.random_state = random_state
        self.base_classifier = None
        self.bagging_model = None
        self.feature_names = None
        self.is_trained = False
        
        print("🚀 Phishing Detection System initialized!")
        print("📊 Using Decision Tree + Bagging Ensemble")
        print("="*60)
    
    def create_models(self, max_depth=10, n_estimators=10):
        """
        Membuat model Decision Tree dan Bagging
        
        Parameters:
        -----------
        max_depth : int
            Maksimal kedalaman decision tree
        n_estimators : int
            Jumlah decision trees dalam ensemble
        """
        print("🔧 Creating Decision Tree + Bagging models...")
        
        # 1. Decision Tree sebagai base classifier
        self.base_classifier = DecisionTreeClassifier(
            max_depth=max_depth,           # Maksimal kedalaman pohon
            min_samples_split=5,          # Minimal samples untuk split node
            min_samples_leaf=2,           # Minimal samples di leaf node
            random_state=self.random_state # Untuk reproducibility
        )
        
        # 2. Bagging dengan Decision Tree
        self.bagging_model = BaggingClassifier(
            base_estimator=self.base_classifier,  # Base classifier yang digunakan
            n_estimators=n_estimators,           # Jumlah decision trees
            max_samples=0.8,                     # 80% data untuk setiap tree
            random_state=self.random_state       # Untuk reproducibility
        )
        
        print("✅ Models created successfully!")
        print(f"   - Decision Tree max_depth: {max_depth}")
        print(f"   - Bagging n_estimators: {n_estimators}")
        print(f"   - Bootstrap samples: 80%")
        print()
    
    def create_dummy_dataset(self, n_samples=11000):
        """
        Membuat dataset dummy untuk demo (sesuai dengan gambar)
        
        Parameters:
        -----------
        n_samples : int
            Jumlah samples yang akan dibuat
        """
        print("📊 Creating dummy dataset for demonstration...")
        
        np.random.seed(self.random_state)
        
        # Distribusi sesuai gambar: 4850 phishing + 6150 legitimate
        phishing_count = int(n_samples * 0.44)  # 44% phishing
        legitimate_count = n_samples - phishing_count  # 56% legitimate
        
        # Buat fitur-fitur dummy (30 fitur)
        features = []
        for i in range(30):
            feature_name = f'feature{i+1}'
            # Generate nilai random dengan distribusi yang masuk akal
            values = np.random.choice([-1, 0, 1], size=n_samples, p=[0.4, 0.2, 0.4])
            features.append(pd.Series(values, name=feature_name))
        
        # Buat target dengan distribusi yang sesuai gambar
        target = pd.Series([-1] * phishing_count + [1] * legitimate_count, name='Result')
        
        # Buat DataFrame
        self.dataset = pd.concat(features + [target], axis=1)
        self.feature_names = [col for col in self.dataset.columns if col != 'Result']
        
        print(f"✅ Dataset created with {n_samples:,} samples")
        print(f"   - Features: {len(self.feature_names)}")
        print(f"   - Phishing (-1): {phishing_count:,} samples ({phishing_count/n_samples*100:.1f}%)")
        print(f"   - Legitimate (1): {legitimate_count:,} samples ({legitimate_count/n_samples*100:.1f}%)")
        print(f"   - Shape: {self.dataset.shape}")
        print()
        
        return self.dataset
    
    def prepare_data(self, test_size=0.2):
        """
        Menyiapkan data untuk training dan testing
        
        Parameters:
        -----------
        test_size : float
            Proporsi data untuk testing
        """
        print("📋 Preparing data for training and testing...")
        
        # Pisahkan fitur dan target
        X = self.dataset.drop('Result', axis=1)
        y = self.dataset['Result']
        
        # Split data
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=test_size, random_state=self.random_state, stratify=y
        )
        
        print("✅ Data prepared successfully!")
        print(f"   - Training set: {self.X_train.shape[0]:,} samples")
        print(f"   - Testing set: {self.X_test.shape[0]:,} samples")
        print(f"   - Features: {self.X_train.shape[1]}")
        print()
    
    def train_model(self):
        """
        Melatih model Decision Tree + Bagging
        """
        if self.bagging_model is None:
            print("❌ Error: Models not created yet. Call create_models() first.")
            return
        
        print("🎯 Training Decision Tree + Bagging model...")
        
        # Fit model dengan data training
        self.bagging_model.fit(self.X_train, self.y_train)
        self.is_trained = True
        
        print("✅ Model trained successfully!")
        print(f"   - Base classifier: {type(self.base_classifier).__name__}")
        print(f"   - Ensemble method: {type(self.bagging_model).__name__}")
        print(f"   - Number of estimators: {self.bagging_model.n_estimators}")
        print()
    
    def evaluate_model(self):
        """
        Evaluasi performa model
        """
        if not self.is_trained:
            print("❌ Error: Model not trained yet. Call train_model() first.")
            return
        
        print("📈 Evaluating model performance...")
        
        # Prediksi pada data testing
        y_pred = self.bagging_model.predict(self.X_test)
        
        # Hitung metrics
        accuracy = accuracy_score(self.y_test, y_pred)
        
        print("✅ Model evaluation completed!")
        print(f"   - Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
        print()
        
        # Classification report
        print("📊 Detailed Classification Report:")
        print("-" * 50)
        print(classification_report(self.y_test, y_pred, 
                                  target_names=['Phishing (-1)', 'Legitimate (1)']))
        
        # Confusion matrix
        cm = confusion_matrix(self.y_test, y_pred)
        print("🔍 Confusion Matrix:")
        print("-" * 30)
        print(f"                Predicted")
        print(f"Actual  Phishing  Legitimate")
        print(f"Phishing    {cm[0,0]:>6}      {cm[0,1]:>6}")
        print(f"Legitimate  {cm[1,0]:>6}      {cm[1,1]:>6}")
        print()
        
        return accuracy, y_pred
    
    def cross_validation(self, cv=5):
        """
        Melakukan cross-validation
        
        Parameters:
        -----------
        cv : int
            Jumlah fold untuk cross-validation
        """
        if not self.is_trained:
            print("❌ Error: Model not trained yet. Call train_model() first.")
            return
        
        print(f"🔄 Performing {cv}-fold cross-validation...")
        
        # Cross-validation
        cv_scores = cross_val_score(self.bagging_model, self.X_train, self.y_train, cv=cv)
        
        print("✅ Cross-validation completed!")
        print(f"   - CV Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
        print(f"   - Individual scores: {cv_scores}")
        print()
        
        return cv_scores
    
    def analyze_feature_importance(self):
        """
        Analisis importance setiap fitur
        """
        if not self.is_trained:
            print("❌ Error: Model not trained yet. Call train_model() first.")
            return
        
        print("🔍 Analyzing feature importance...")
        
        # Ambil feature importance dari base classifier
        feature_importance = self.base_classifier.feature_importances_
        
        # Buat DataFrame feature importance
        importance_df = pd.DataFrame({
            'Feature': self.feature_names,
            'Importance': feature_importance
        })
        
        # Sort berdasarkan importance
        importance_df = importance_df.sort_values('Importance', ascending=False)
        
        print("✅ Feature importance analysis completed!")
        print("📊 Top 10 Most Important Features:")
        print("-" * 50)
        for i, (_, row) in enumerate(importance_df.head(10).iterrows()):
            print(f"{i+1:2d}. {row['Feature']:<15} : {row['Importance']:.4f}")
        print()
        
        # Plot feature importance
        plt.figure(figsize=(12, 8))
        top_features = importance_df.head(15)
        plt.barh(range(len(top_features)), top_features['Importance'])
        plt.yticks(range(len(top_features)), top_features['Feature'])
        plt.xlabel('Feature Importance')
        plt.title('Top 15 Feature Importance')
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig('feature_importance.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        return importance_df
    
    def hyperparameter_tuning(self):
        """
        Hyperparameter tuning menggunakan Grid Search
        """
        if not self.is_trained:
            print("❌ Error: Model not trained yet. Call train_model() first.")
            return
        
        print("⚙️ Performing hyperparameter tuning...")
        
        # Parameter grid untuk tuning
        param_grid = {
            'base_estimator__max_depth': [5, 10, 15],
            'base_estimator__min_samples_split': [2, 5, 10],
            'n_estimators': [5, 10, 15],
            'max_samples': [0.7, 0.8, 0.9]
        }
        
        # Grid search
        grid_search = GridSearchCV(
            self.bagging_model, 
            param_grid, 
            cv=3, 
            scoring='accuracy',
            n_jobs=-1
        )
        
        grid_search.fit(self.X_train, self.y_train)
        
        print("✅ Hyperparameter tuning completed!")
        print(f"   - Best parameters: {grid_search.best_params_}")
        print(f"   - Best CV score: {grid_search.best_score_:.4f}")
        print()
        
        return grid_search
    
    def save_model(self, filename='phishing_detection_model.pkl'):
        """
        Menyimpan model yang sudah dilatih
        
        Parameters:
        -----------
        filename : str
            Nama file untuk menyimpan model
        """
        if not self.is_trained:
            print("❌ Error: Model not trained yet. Call train_model() first.")
            return
        
        print(f"💾 Saving model to {filename}...")
        
        # Save model
        joblib.dump(self.bagging_model, filename)
        
        print("✅ Model saved successfully!")
        print(f"   - File: {filename}")
        print(f"   - Size: {self.bagging_model.__sizeof__()} bytes")
        print()
    
    def load_model(self, filename='phishing_detection_model.pkl'):
        """
        Load model yang sudah disimpan
        
        Parameters:
        -----------
        filename : str
            Nama file model yang akan di-load
        """
        print(f"📂 Loading model from {filename}...")
        
        try:
            self.bagging_model = joblib.load(filename)
            self.is_trained = True
            print("✅ Model loaded successfully!")
        except FileNotFoundError:
            print(f"❌ Error: File {filename} not found.")
        except Exception as e:
            print(f"❌ Error loading model: {e}")
        print()
    
    def predict_url(self, features):
        """
        Prediksi untuk URL baru
        
        Parameters:
        -----------
        features : list or array
            Fitur-fitur yang diekstrak dari URL
            
        Returns:
        --------
        dict : Hasil prediksi
        """
        if not self.is_trained:
            print("❌ Error: Model not trained yet. Call train_model() first.")
            return None
        
        print("🔮 Making prediction for new URL...")
        
        # Reshape features jika perlu
        if isinstance(features, list):
            features = np.array(features).reshape(1, -1)
        
        # Prediksi
        prediction = self.bagging_model.predict(features)[0]
        confidence = self.bagging_model.predict_proba(features)[0].max()
        
        # Interpretasi hasil
        if prediction == -1:
            result = "WASPADA - Terindikasi Phishing"
            status = "Phishing"
        else:
            result = "AMAN - Website Legitimate"
            status = "Legitimate"
        
        # Hasil prediksi
        prediction_result = {
            "prediction": prediction,
            "status": status,
            "result": result,
            "confidence": confidence,
            "confidence_percentage": f"{confidence*100:.2f}%"
        }
        
        print("✅ Prediction completed!")
        print(f"   - Result: {result}")
        print(f"   - Confidence: {prediction_result['confidence_percentage']}")
        print()
        
        return prediction_result
    
    def demonstrate_bagging(self):
        """
        Demonstrasi cara kerja Bagging
        """
        print("🎯 Demonstrating Bagging (Bootstrap Aggregating)...")
        print("="*60)
        
        # Contoh bootstrap sampling
        print("1. BOOTSTRAP SAMPLING:")
        print("   Original Data: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]")
        print("   Tree 1: [2, 2, 4, 5, 7, 8, 9, 10]  # 8 samples, ada duplikasi")
        print("   Tree 2: [1, 3, 3, 6, 7, 8, 9, 10]  # 8 samples, ada duplikasi")
        print("   Tree 3: [1, 2, 4, 5, 6, 7, 8, 9]   # 8 samples, ada duplikasi")
        print()
        
        # Contoh majority voting
        print("2. MAJORITY VOTING:")
        print("   Tree 1: Phishing (-1)")
        print("   Tree 2: Phishing (-1)")
        print("   Tree 3: Legitimate (1)")
        print("   Tree 4: Phishing (-1)")
        print("   Tree 5: Phishing (-1)")
        print("   Tree 6: Legitimate (1)")
        print("   Tree 7: Phishing (-1)")
        print("   Tree 8: Phishing (-1)")
        print("   Tree 9: Phishing (-1)")
        print("   Tree 10: Phishing (-1)")
        print()
        print("   Final Prediction: Phishing (-1)  # 7 votes vs 3 votes")
        print()
        
        print("✅ Bagging demonstration completed!")
        print()

def main():
    """
    Main function untuk demonstrasi lengkap
    """
    print("🚀 PHISHING DETECTION SYSTEM - COMPLETE DEMONSTRATION")
    print("="*70)
    print()
    
    # 1. Inisialisasi sistem
    system = PhishingDetectionSystem(random_state=42)
    
    # 2. Buat dataset dummy
    dataset = system.create_dummy_dataset(n_samples=11000)
    
    # 3. Buat model
    system.create_models(max_depth=10, n_estimators=10)
    
    # 4. Siapkan data
    system.prepare_data(test_size=0.2)
    
    # 5. Latih model
    system.train_model()
    
    # 6. Evaluasi model
    accuracy, predictions = system.evaluate_model()
    
    # 7. Cross-validation
    cv_scores = system.cross_validation(cv=5)
    
    # 8. Analisis feature importance
    importance_df = system.analyze_feature_importance()
    
    # 9. Hyperparameter tuning (optional, bisa skip jika lama)
    print("⚠️  Hyperparameter tuning akan memakan waktu lama...")
    response = input("   Continue with hyperparameter tuning? (y/n): ").lower()
    if response == 'y':
        grid_search = system.hyperparameter_tuning()
    
    # 10. Simpan model
    system.save_model()
    
    # 11. Demonstrasi Bagging
    system.demonstrate_bagging()
    
    # 12. Contoh prediksi
    print("🔮 EXAMPLE PREDICTION:")
    print("-" * 30)
    
    # Buat fitur dummy untuk contoh
    dummy_features = np.random.choice([-1, 0, 1], size=30)
    prediction_result = system.predict_url(dummy_features)
    
    # 13. Summary
    print("📋 SYSTEM SUMMARY:")
    print("=" * 50)
    print(f"✅ Dataset: {dataset.shape[0]:,} samples, {dataset.shape[1]-1} features")
    print(f"✅ Model: Decision Tree + Bagging Ensemble")
    print(f"✅ Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"✅ Cross-validation: {cv_scores.mean():.4f} (+/- {cv_scores.std()*2:.4f})")
    print(f"✅ Model saved: phishing_detection_model.pkl")
    print()
    
    print("🎉 DEMONSTRATION COMPLETED SUCCESSFULLY!")
    print("=" * 50)
    print("Files generated:")
    print("   📊 feature_importance.png - Feature importance plot")
    print("   💾 phishing_detection_model.pkl - Trained model")
    print()
    print("Next steps:")
    print("   1. Use the trained model for real predictions")
    print("   2. Fine-tune hyperparameters for better performance")
    print("   3. Integrate with web interface")
    print("   4. Deploy to production")

if __name__ == "__main__":
    # Jalankan demonstrasi lengkap
    main()
