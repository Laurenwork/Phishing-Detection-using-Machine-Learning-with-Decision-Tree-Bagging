<?php
require_once 'config.php';

echo "<h2>Status Database Phishingdetect</h2>";

// Cek koneksi database
if ($conn->connect_error) {
    echo "<p style='color: red;'>❌ Koneksi database gagal: " . $conn->connect_error . "</p>";
    exit();
} else {
    echo "<p style='color: green;'>✅ Koneksi database berhasil</p>";
}

// Cek apakah database ada
$result = $conn->query("SHOW DATABASES LIKE 'phishingdetect'");
if ($result->num_rows > 0) {
    echo "<p style='color: green;'>✅ Database 'phishingdetect' ditemukan</p>";
} else {
    echo "<p style='color: red;'>❌ Database 'phishingdetect' tidak ditemukan</p>";
    exit();
}

// Cek tabel users
$result = $conn->query("SHOW TABLES LIKE 'users'");
if ($result->num_rows > 0) {
    echo "<p style='color: green;'>✅ Tabel 'users' ditemukan</p>";
    
    // Cek struktur tabel users
    $result = $conn->query("DESCRIBE users");
    echo "<h3>Struktur Tabel Users:</h3>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>❌ Tabel 'users' tidak ditemukan</p>";
}

// Cek tabel riwayat
$result = $conn->query("SHOW TABLES LIKE 'riwayat'");
if ($result->num_rows > 0) {
    echo "<p style='color: green;'>✅ Tabel 'riwayat' ditemukan</p>";
    
    // Cek struktur tabel riwayat
    $result = $conn->query("DESCRIBE riwayat");
    echo "<h3>Struktur Tabel Riwayat:</h3>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>❌ Tabel 'riwayat' tidak ditemukan</p>";
}

// Cek foreign key
$result = $conn->query("
    SELECT 
        TABLE_NAME,
        COLUMN_NAME,
        CONSTRAINT_NAME,
        REFERENCED_TABLE_NAME,
        REFERENCED_COLUMN_NAME
    FROM 
        INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
    WHERE 
        REFERENCED_TABLE_SCHEMA = 'phishingdetect' 
        AND REFERENCED_TABLE_NAME IS NOT NULL
");

if ($result->num_rows > 0) {
    echo "<h3>Foreign Keys:</h3>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Table</th><th>Column</th><th>References</th><th>Referenced Column</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['TABLE_NAME'] . "</td>";
        echo "<td>" . $row['COLUMN_NAME'] . "</td>";
        echo "<td>" . $row['REFERENCED_TABLE_NAME'] . "</td>";
        echo "<td>" . $row['REFERENCED_COLUMN_NAME'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>❌ Tidak ada foreign key yang ditemukan</p>";
}

// Cek data users
$result = $conn->query("SELECT COUNT(*) as count FROM users");
if ($result) {
    $count = $result->fetch_assoc()['count'];
    echo "<p style='color: blue;'>📊 Jumlah users: " . $count . "</p>";
}

// Cek data riwayat
$result = $conn->query("SELECT COUNT(*) as count FROM riwayat");
if ($result) {
    $count = $result->fetch_assoc()['count'];
    echo "<p style='color: blue;'>📊 Jumlah riwayat: " . $count . "</p>";
}

echo "<br><p><strong>Jika ada masalah, jalankan file fix_database.sql di phpMyAdmin</strong></p>";
?> 