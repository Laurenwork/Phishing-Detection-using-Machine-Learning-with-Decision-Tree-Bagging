<?php
session_start();
session_destroy();
$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'login.php';
header('Location: ' . $redirect);
exit(); 