# Tutorial Implementasi Machine Learning: Langkah demi Langkah

Dokumen ini menjelaskan tahapan utama dalam implementasi machine learning, mulai dari pengumpulan data hingga evaluasi model, lengkap dengan penjelasan dan contoh kode Python menggunakan scikit-learn dan pandas.

---

## 1. Data Collection (Pengumpulan Data)

Tahap pertama adalah mengumpulkan data yang relevan untuk masalah yang ingin diselesaikan. Data dapat diperoleh dari berbagai sumber seperti file CSV, database, API, atau scraping website.

**Contoh kode:**

```python
import pandas as pd
# Membaca data dari file CSV
df = pd.read_csv('dataset_phishing.csv')
# Menampilkan 5 baris pertama
df.head()
```

**Output:**

```
        url        feature1  feature2  ...  featureN  label
0  http://...         ...       ...   ...     ...      1
1  http://...         ...       ...   ...     ...      0
2  http://...         ...       ...   ...     ...      1
3  http://...         ...       ...   ...     ...      0
4  http://...         ...       ...   ...     ...      1
```

---

## 2. Data Preprocessing (Pra-pemrosesan Data)

Data yang dikumpulkan biasanya perlu dibersihkan dan diproses agar siap digunakan untuk pelatihan model. Proses ini meliputi penanganan missing value, encoding data kategorikal, normalisasi, dan pembagian data.

**Contoh kode:**

```python
# Menghapus baris dengan nilai kosong
df = df.dropna()

# Jika ada fitur kategorikal, lakukan encoding
# Contoh: Label encoding pada kolom 'label'
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
df['label'] = le.fit_transform(df['label'])

# Memisahkan fitur dan label
y = df['label']
X = df.drop('label', axis=1)

# Membagi data menjadi data latih dan data uji
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```

**Output:**

```
# Tidak ada output langsung, namun data sudah siap untuk training.
# Cek shape data:
print(X_train.shape, X_test.shape)
# Output contoh:
(800, 30) (200, 30)
```

---

## 3. Data Exploration (Eksplorasi Data)

Eksplorasi data bertujuan untuk memahami karakteristik data, distribusi fitur, dan hubungan antar variabel. Proses ini dapat dilakukan dengan statistik deskriptif dan visualisasi.

**Contoh kode:**

```python
# Statistik deskriptif
df.describe()

# Visualisasi distribusi label
import matplotlib.pyplot as plt
df['label'].value_counts().plot(kind='bar')
plt.title('Distribusi Label')
plt.xlabel('Label')
plt.ylabel('Jumlah')
plt.show()
```

**Output:**  
Grafik batang yang menunjukkan jumlah data untuk masing-masing kelas (misal: 0 = Aman, 1 = Phishing).

---

## 4. Model Building & Training (Pembangunan & Pelatihan Model)

Pada tahap ini, model machine learning dibangun dan dilatih menggunakan data latih. Contoh di bawah menggunakan Decision Tree dan Bagging.

**Contoh kode:**

```python
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier

# Model Decision Tree
dt_model = DecisionTreeClassifier(criterion='gini', random_state=42)
dt_model.fit(X_train, y_train)

# Model Bagging dengan Decision Tree sebagai base estimator
bagging_model = BaggingClassifier(
    base_estimator=DecisionTreeClassifier(),
    n_estimators=100,
    random_state=42
)
bagging_model.fit(X_train, y_train)
```

**Output:**

```
# Tidak ada output langsung, model sudah terlatih.
print(dt_model)
# Output:
DecisionTreeClassifier(random_state=42)
print(bagging_model)
# Output:
BaggingClassifier(base_estimator=DecisionTreeClassifier(), n_estimators=100, random_state=42)
```

---

## 5. Model Evaluation (Evaluasi Model)

Setelah model dilatih, performanya dievaluasi menggunakan data uji. Evaluasi dapat dilakukan dengan menghitung akurasi, precision, recall, F1-score, dan confusion matrix.

**Contoh kode:**

```python
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Evaluasi Decision Tree
y_pred_dt = dt_model.predict(X_test)
print('Akurasi Decision Tree:', accuracy_score(y_test, y_pred_dt))
print(classification_report(y_test, y_pred_dt))
print('Confusion Matrix:\n', confusion_matrix(y_test, y_pred_dt))

# Evaluasi Bagging
y_pred_bag = bagging_model.predict(X_test)
print('Akurasi Bagging:', accuracy_score(y_test, y_pred_bag))
print(classification_report(y_test, y_pred_bag))
print('Confusion Matrix:\n', confusion_matrix(y_test, y_pred_bag))
```

**Output:**

```
Akurasi Decision Tree: 0.93
              precision    recall  f1-score   support

           0       0.92      0.94      0.93       100
           1       0.94      0.92      0.93       100

    accuracy                           0.93       200
   macro avg       0.93      0.93      0.93       200
weighted avg       0.93      0.93      0.93       200

Confusion Matrix:
[[94  6]
 [ 8 92]]

Akurasi Bagging: 0.96
              precision    recall  f1-score   support

           0       0.96      0.97      0.96       100
           1       0.97      0.95      0.96       100

    accuracy                           0.96       200
   macro avg       0.96      0.96      0.96       200
weighted avg       0.96      0.96      0.96       200

Confusion Matrix:
[[97  3]
 [ 5 95]]
```

---

Dengan mengikuti tahapan di atas, Anda dapat membangun sistem deteksi phishing berbasis machine learning secara sistematis dan terstruktur.

**Catatan:**

- Nilai akurasi, precision, recall, dan confusion matrix akan berbeda tergantung dataset yang digunakan.
- Jika ingin output visual (grafik), pastikan menjalankan kode di lingkungan yang mendukung tampilan grafik (Jupyter Notebook, Google Colab, dsb).

Jika ingin contoh output lain (misal: prediksi satu URL, feature importance, dsb), silakan sebutkan!
