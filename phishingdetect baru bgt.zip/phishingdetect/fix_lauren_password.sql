-- File untuk memperbaiki password Lauren
USE phishingdetect;

-- Update password Lauren dengan hash yang benar untuk 'lauren123'
UPDATE users 
SET password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' 
WHERE username = 'Lauren' AND email = 'laurensandro9@gmail.com';

-- Jika user Lauren belum ada, buat baru
INSERT INTO users (username, email, password, role) 
SELECT 'Lauren', 'laurensandro9@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'Lauren');

-- Tampilkan user Lauren
SELECT id, username, email, role FROM users WHERE username = 'Lauren'; 