# ============================================================
# EXPLORATORY DATA ANALYSIS (EDA) COMPLETE CODE
# PHISHING DETECTION DATASET
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import rcParams

# Set style untuk plot yang lebih menarik
plt.style.use('seaborn-v0_8')
rcParams['figure.figsize'] = (12, 8)
rcParams['font.size'] = 10

# ============================================================
# 1. LOAD DATASET
# ============================================================
print("Loading dataset...")
# Ganti 'dataset.csv' dengan nama file dataset Anda
try:
    # Coba load dari file CSV
    df = pd.read_csv('dataset.csv')
except FileNotFoundError:
    
    # Jika file tidak ada, buat dataset dummy untuk demo
    print("File dataset.csv tidak ditemukan. Membuat dataset dummy...")
    
    # Buat dataset dummy dengan 30 fitur + 1 target
    np.random.seed(42)
    n_samples = 11000  # Sesuai dengan gambar (4850 + 6150)
    
    # Buat fitur-fitur dummy
    features = []
    for i in range(30):
        feature_name = f'feature{i+1}'
        # Generate nilai random dengan distribusi yang masuk akal
        values = np.random.choice([-1, 0, 1], size=n_samples, p=[0.4, 0.2, 0.4])
        features.append(pd.Series(values, name=feature_name))
    
    # Buat target dengan distribusi yang sesuai gambar
    phishing_count = 4850  # Sesuai gambar
    legitimate_count = 6150  # Sesuai gambar
    target = pd.Series([-1] * phishing_count + [1] * legitimate_count, name='Result')
    
    # Buat DataFrame
    df = pd.concat(features + [target], axis=1)
    print(f"Dataset dummy berhasil dibuat dengan {n_samples} samples")

print(f"Dataset shape: {df.shape}")
print(f"Columns: {list(df.columns)}")

# ============================================================
# 2. DESCRIPTIVE STATISTICS
# ============================================================
print("\n" + "="*80)
print("DESCRIPTIVE STATISTICS")
print("="*80)


# Generate descriptive statistics
desc_stats = df.describe()
print(desc_stats)

# Simpan ke file
desc_stats.to_csv('descriptive_statistics.csv')
print("\nDescriptive statistics disimpan ke 'descriptive_statistics.csv'")

# ============================================================
# 3. MISSING VALUES ANALYSIS
# ============================================================
print("\n" + "="*80)
print("MISSING VALUES ANALYSIS")
print("="*80)

# Hitung missing values
missing_count = df.isnull().sum()
missing_percentage = (missing_count / len(df)) * 100

# Buat DataFrame missing values
missing_df = pd.DataFrame({
    'Kolom': df.columns,
    'Missing Count': missing_count,
    'Missing Percentage': missing_percentage
})

print(missing_df)

# Simpan ke file
missing_df.to_csv('missing_values_analysis.csv', index=False)
print("\nMissing values analysis disimpan ke 'missing_values_analysis.csv'")

# ============================================================
# 4. LABEL DISTRIBUTION ANALYSIS
# ============================================================
print("\n" + "="*80)
print("LABEL DISTRIBUTION ANALYSIS")
print("="*80)

# Hitung distribusi label
label_counts = df['Result'].value_counts()
label_percentages = (label_counts / len(df)) * 100

print("Label Distribution:")
print(f"Phishing (-1): {label_counts[-1]} samples ({label_percentages[-1]:.2f}%)")
print(f"Legitimate (1): {label_counts[1]} samples ({label_percentages[1]:.2f}%)")

# Simpan ke file
label_dist = pd.DataFrame({
    'Label': ['Phishing (-1)', 'Legitimate (1)'],
    'Count': [label_counts[-1], label_counts[1]],
    'Percentage': [label_percentages[-1], label_percentages[1]]
})
label_dist.to_csv('label_distribution.csv', index=False)
print("Label distribution disimpan ke 'label_distribution.csv'")

# ============================================================
# 5. VISUALIZATIONS
# ============================================================
print("\n" + "="*80)
print("GENERATING VISUALIZATIONS...")
print("="*80)

# Set style untuk plot
plt.style.use('default')
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
fig.suptitle('Exploratory Data Analysis - Phishing Detection Dataset', fontsize=16, fontweight='bold')

#Label Distribution Bar Chart
ax1 = axes[0, 0]
labels = ['Phishing (-1)', 'Aman (1)']
counts = [label_counts[-1], label_counts[1]]
colors = ['#ff6b6b', '#4ecdc4']

bars = ax1.bar(labels, counts, color=colors, alpha=0.8, edgecolor='black', linewidth=1)
ax1.set_title('Distribusi Label pada Dataset', fontweight='bold', fontsize=14)
ax1.set_ylabel('Jumlah Data', fontweight='bold')
ax1.set_xlabel('Label (1 = Aman, -1 = Phishing)', fontweight='bold')

# Tambahkan nilai di atas bar
for bar, count in zip(bars, counts):
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height + 100,
             f'{count:,}', ha='center', va='bottom', fontweight='bold')

# 2. Missing Values Heatmap
ax2 = axes[0, 1]
missing_matrix = df.isnull().astype(int)
sns.heatmap(missing_matrix, cbar=True, ax=ax2, cmap='viridis')
ax2.set_title('Missing Values Heatmap', fontweight='bold', fontsize=14)
ax2.set_xlabel('Features')
ax2.set_ylabel('Samples')

# 3. Feature Value Distribution
ax3 = axes[1, 0]
# Ambil beberapa fitur untuk ditampilkan
sample_features = df.columns[:10]  # 10 fitur pertama
feature_stats = df[sample_features].describe().loc[['mean', 'std']]
feature_stats.plot(kind='bar', ax=ax3, color=['#ff6b6b', '#4ecdc4'])
ax3.set_title('Feature Statistics (Mean & Std)', fontweight='bold', fontsize=14)
ax3.set_ylabel('Value')
ax3.set_xlabel('Features')
ax3.legend(['Mean', 'Standard Deviation'])
ax3.tick_params(axis='x', rotation=45)

# 4. Correlation with Target
ax4 = axes[1, 1]
# Hitung korelasi dengan target
correlations = df.corr()['Result'].sort_values(ascending=False)
top_correlations = correlations.head(10)
top_correlations.plot(kind='barh', ax=ax4, color='#ff6b6b', alpha=0.8)
ax4.set_title('Top 10 Features Correlation with Target', fontweight='bold', fontsize=14)
ax4.set_xlabel('Correlation Coefficient')

plt.tight_layout()
plt.savefig('eda_visualizations.png', dpi=300, bbox_inches='tight')
print("Visualizations disimpan ke 'eda_visualizations.png'")

# ============================================================
# 6. DETAILED STATISTICAL ANALYSIS
# ============================================================
print("\n" + "="*80)
print("DETAILED STATISTICAL ANALYSIS")
print("="*80)

# Info dataset
print("\nDataset Info:")
print(f"Shape: {df.shape}")
print(f"Memory Usage: {df.memory_usage(deep=True).sum() / 1024:.2f} KB")
print(f"Data Types: {df.dtypes.value_counts().to_dict()}")

# Check duplicates
duplicates = df.duplicated().sum()
print(f"Duplicate Rows: {duplicates}")

# Feature categories
url_features = [col for col in df.columns if 'URL' in col or 'Domain' in col or 'IP' in col]
security_features = [col for col in df.columns if 'SSL' in col or 'HTTPS' in col or 'Port' in col]
content_features = [col for col in df.columns if 'Content' in col or 'Link' in col or 'Page' in col]

print(f"\nFeature Categories:")
print(f"URL & Domain Features: {len(url_features)}")
print(f"Security Features: {len(security_features)}")
print(f"Content Features: {len(content_features)}")

# ============================================================
# 7. SAVE COMPLETE EDA REPORT
# ============================================================
print("\n" + "="*80)
print("SAVING COMPLETE EDA REPORT...")
print("="*80)

# Buat report lengkap
report = f"""
EXPLORATORY DATA ANALYSIS (EDA) REPORT
PHISHING DETECTION DATASET
{'='*60}

1. DATASET OVERVIEW
{'='*60}
- Total Samples: {len(df):,}
- Total Features: {len(df.columns)-1}
- Target Column: Result
- Dataset Shape: {df.shape}

2. MISSING VALUES SUMMARY
{'='*60}
- Total Missing Values: {missing_count.sum()}
- Features with Missing Values: {(missing_count > 0).sum()}
- Data Completeness: {((len(df) * len(df.columns) - missing_count.sum()) / (len(df) * len(df.columns)) * 100):.2f}%

3. LABEL DISTRIBUTION
{'='*60}
- Phishing (-1): {label_counts[-1]:,} samples ({label_percentages[-1]:.2f}%)
- Legitimate (1): {label_counts[1]:,} samples ({label_percentages[1]:.2f}%)
- Balance Ratio: {label_counts[1]/label_counts[-1]:.2f}

4. FEATURE CHARACTERISTICS
{'='*60}
- Data Types: {df.dtypes.value_counts().to_dict()}
- Memory Usage: {df.memory_usage(deep=True).sum() / 1024:.2f} KB
- Duplicate Rows: {duplicates}

5. RECOMMENDATIONS
{'='*60}
- Dataset siap untuk machine learning training
- Tidak ada missing values yang perlu dihandle
- Distribusi label cukup seimbang
- Semua fitur numerik, cocok untuk tree-based algorithms

{'='*60}
Report generated on: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

# Simpan report
with open('eda_complete_report.txt', 'w', encoding='utf-8') as f:
    f.write(report)

print("Complete EDA report disimpan ke 'eda_complete_report.txt'")

# ============================================================
# 8. FINAL SUMMARY
# ============================================================
print("\n" + "="*80)
print("EDA COMPLETED SUCCESSFULLY!")
print("="*80)
print("Files generated:")
print("✅ descriptive_statistics.csv - Descriptive statistics")
print("✅ missing_values_analysis.csv - Missing values analysis")
print("✅ label_distribution.csv - Label distribution")
print("✅ eda_visualizations.png - Visualization plots")
print("✅ eda_complete_report.txt - Complete EDA report")

print(f"\nDataset Summary:")
print(f"📊 Shape: {df.shape}")
print(f"🔍 Missing Values: {missing_count.sum()}")
print(f"🏷️  Labels: {label_counts.to_dict()}")
print(f"💾 Memory: {df.memory_usage(deep=True).sum() / 1024:.2f} KB")

print("\nEDA selesai! Semua file telah disimpan.")
