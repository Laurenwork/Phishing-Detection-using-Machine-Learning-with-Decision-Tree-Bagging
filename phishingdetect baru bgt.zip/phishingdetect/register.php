<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}
require 'config.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'user';
    $cek = $conn->query("SELECT id FROM users WHERE username='$username'");
    if ($cek->num_rows > 0) {
        $msg = 'Username sudah terdaftar!';
    } else {
        $conn->query("INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')");
        $msg = 'Registrasi berhasil, silakan login!';
    }
}
?>
<?php include 'navbar.php'; ?>
<link rel="stylesheet" href="static/style.css">
<div class="container">
    <div class="card animate__animated animate__fadeInUp" style="max-width:400px;margin:40px auto;">
        <h2 style="text-align:center;color:#2563eb;"><i class="fas fa-user-plus"></i> Registrasi</h2>
        <?php if ($msg): ?>
            <div class="result-box <?= strpos($msg,'berhasil')!==false?'safe':'phishing' ?>" style="margin-bottom:16px;"> <?= htmlspecialchars($msg) ?> </div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> Username</label>
                <input type="text" name="username" id="username" class="pulse-focus" required style="width:100%;margin-bottom:12px;">
            </div>
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" id="password" class="pulse-focus" required style="width:100%;margin-bottom:18px;">
            </div>
            <button type="submit" class="btn-animated" style="width:100%;">Daftar</button>
        </form>
        <p style="text-align:center;margin-top:18px;">Sudah punya akun? <a href="login.php" style="color:#2563eb;font-weight:bold;">Login</a></p>
    </div>
</div> 