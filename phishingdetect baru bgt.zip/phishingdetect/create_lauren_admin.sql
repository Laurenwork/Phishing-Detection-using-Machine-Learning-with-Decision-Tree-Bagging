-- File untuk membuat user admin Lauren
USE phishingdetect;

-- Hapus user Lauren jika sudah ada
DELETE FROM riwayat WHERE username = 'Lauren';
DELETE FROM users WHERE username = 'Lauren';

-- Masukkan user admin Lauren dengan password lauren123
INSERT INTO users (username, email, password, role) VALUES 
('Lauren', 'laurensandro9@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Tampilkan user yang baru dibuat
SELECT id, username, email, role FROM users WHERE username = 'Lauren'; 