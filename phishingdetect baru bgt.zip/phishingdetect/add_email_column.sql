-- File untuk menambahkan kolom email ke tabel users yang sudah ada
USE phishingdetect;

-- Tambahkan kolom email jika belum ada
ALTER TABLE users ADD COLUMN IF NOT EXISTS email VARCHAR(100) NOT NULL DEFAULT 'user@example.com' AFTER username;

-- Update email untuk user yang sudah ada (ganti dengan email yang sesuai)
-- UPDATE users SET email = CONCAT(username, '@example.com') WHERE email = 'user@example.com'; 