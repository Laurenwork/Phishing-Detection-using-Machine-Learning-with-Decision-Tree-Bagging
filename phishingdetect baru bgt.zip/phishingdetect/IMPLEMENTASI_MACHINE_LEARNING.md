# Implementasi Machine Learning: Decision Tree & Bagging untuk Deteksi Phishing

## 📋 Daftar Isi

1. [Konsep Dasar](#konsep-dasar)
2. [Arsitektur Sistem](#arsitektur-sistem)
3. [Ekstraksi Fitur](#ekstraksi-fitur)
4. [Model Machine Learning](#model-machine-learning)
5. [Implementasi Decision Tree](#implementasi-decision-tree)
6. [Implementasi Bagging](#implementasi-bagging)
7. [Analisis Konten](#analisis-konten)
8. [Workflow Sistem](#workflow-sistem)
9. [Evaluasi Model](#evaluasi-model)
10. [Penggunaan](#penggunaan)

## 🎯 Konsep Dasar

### Decision Tree Classifier

- **Definisi**: Algoritma supervised learning yang membuat model prediksi dalam bentuk struktur pohon keputusan
- **Keunggulan**:
  - Mudah diinterpretasi
  - Dapat menangani data numerik dan kategorikal
  - Tidak memerlukan normalisasi data
- **Kekurangan**:
  - Rentan terhadap overfitting
  - Sensitif terhadap perubahan data training

### Bagging (Bootstrap Aggregating)

- **Definisi**: Teknik ensemble learning yang menggabungkan beberapa model untuk meningkatkan akurasi
- **Prinsip**:
  - Membuat multiple subset dari data training (bootstrap sampling)
  - Melatih model terpisah pada setiap subset
  - Menggabungkan prediksi dengan voting/averaging
- **Keunggulan**:
  - Mengurangi overfitting
  - Meningkatkan stabilitas model
  - Mengurangi variance

## 🏗️ Arsitektur Sistem

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   URL Input     │───▶│ Feature Extraction│───▶│ ML Model        │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │                       │
                                ▼                       ▼
                       ┌─────────────────┐    ┌─────────────────┐
                       │ Content Analysis│    │ Decision Tree   │
                       └─────────────────┘    └─────────────────┘
                                │                       │
                                ▼                       ▼
                       ┌─────────────────┐    ┌─────────────────┐
                       │ Bagging         │    │ Final Result    │
                       └─────────────────┘    └─────────────────┘
```

## 🔍 Ekstraksi Fitur

### 30 Fitur yang Diekstrak:

#### 1. Fitur URL (1-7)

```python
# 1. Having_IP_Address
# 2. URL_Length
# 3. Shortining_Service
# 4. Having_At_Symbol
# 5. Double_Slash_Redirecting
# 6. Prefix_Suffix
# 7. Having_Sub_Domain
```

#### 2. Fitur Domain (8-15)

```python
# 8. SSLfinal_State
# 9. Domain_registeration_length
# 10. Favicon
# 11. Port
# 12. HTTPS_token
# 13. Request_URL
# 14. URL_of_Anchor
# 15. Links_in_tags
```

#### 3. Fitur Server (16-22)

```python
# 16. SFH
# 17. Submitting_to_email
# 18. Abnormal_URL
# 19. Redirect
# 20. on_mouseover
# 21. RightClick
# 22. popUpWidnow
```

#### 4. Fitur Konten (23-30)

```python
# 23. Iframe
# 24. age_of_domain
# 25. DNSRecord
# 26. web_traffic
# 27. Page_Rank
# 28. Google_Index
# 29. Links_pointing_to_page
# 30. Statistical_report
```

### Implementasi Ekstraksi Fitur:

```python
def generate_data_set(url):
    data_set = []

    # Konversi URL ke format standar
    if not re.match(r"^https?", url):
        url = "http://" + url

    # Ekstraksi domain
    domain = re.findall(r"://([^/]+)/?", url)[0]

    # Ekstraksi fitur-fitur
    features = []

    # 1. Having_IP_Address
    features.append(1 if re.match(r"^\d+\.\d+\.\d+\.\d+", domain) else -1)

    # 2. URL_Length
    features.append(1 if len(url) > 75 else -1)

    # 3. Shortining_Service
    shorteners = ['bit.ly', 'goo.gl', 'tinyurl.com']
    features.append(1 if any(s in url for s in shorteners) else -1)

    # ... dan seterusnya untuk 30 fitur

    return features
```

## 🤖 Model Machine Learning

### Implementasi Decision Tree:

```python
from sklearn.tree import DecisionTreeClassifier

# Konfigurasi Decision Tree
decision_tree = DecisionTreeClassifier(
    criterion='gini',           # Kriteria split
    max_depth=None,            # Kedalaman maksimal
    min_samples_split=2,       # Minimal samples untuk split
    min_samples_leaf=1,        # Minimal samples per leaf
    random_state=42
)
```

### Implementasi Bagging:

```python
from sklearn.ensemble import BaggingClassifier

# Konfigurasi Bagging dengan Decision Tree
bagging_model = BaggingClassifier(
    base_estimator=DecisionTreeClassifier(),
    n_estimators=100,          # Jumlah model
    max_samples=1.0,           # Ukuran sample per model
    max_features=1.0,          # Jumlah fitur per model
    bootstrap=True,            # Bootstrap sampling
    random_state=42
)
```

## 🌳 Implementasi Decision Tree

### Algoritma Decision Tree:

1. **Root Node**: Mulai dengan seluruh dataset
2. **Splitting**: Pilih fitur terbaik untuk split berdasarkan:
   - Gini Index: `Gini = 1 - Σ(p²)`
   - Information Gain: `IG = Entropy(parent) - Σ(weight × Entropy(child))`
3. **Recursive Splitting**: Ulangi sampai kriteria berhenti terpenuhi
4. **Leaf Node**: Prediksi kelas mayoritas

### Contoh Implementasi:

```python
def train_decision_tree(X, y):
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=7
    )

    # Buat dan latih model
    dt_model = DecisionTreeClassifier(random_state=42)
    dt_model.fit(X_train, y_train)

    # Evaluasi
    accuracy = dt_model.score(X_test, y_test)
    print(f'Akurasi Decision Tree: {accuracy*100:.2f}%')

    return dt_model
```

## 📦 Implementasi Bagging

### Bootstrap Sampling:

```python
def bootstrap_sample(X, y, n_samples):
    """Membuat bootstrap sample dari dataset"""
    n = len(X)
    indices = np.random.choice(n, size=n_samples, replace=True)
    return X[indices], y[indices]
```

### Ensemble Prediction:

```python
def bagging_predict(models, X):
    """Menggabungkan prediksi dari multiple model"""
    predictions = []
    for model in models:
        pred = model.predict(X)
        predictions.append(pred)

    # Voting majority
    ensemble_pred = np.mean(predictions, axis=0)
    return (ensemble_pred > 0.5).astype(int)
```

### Implementasi Lengkap Bagging:

```python
def train_bagging_model(X, y, n_estimators=100):
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=7
    )

    # Buat Bagging Classifier
    bagging_model = BaggingClassifier(
        DecisionTreeClassifier(),
        n_estimators=n_estimators,
        max_samples=1.0,
        max_features=1.0,
        random_state=42
    )

    # Training
    bagging_model.fit(X_train, y_train)

    # Evaluasi
    accuracy = bagging_model.score(X_test, y_test)
    print(f'Akurasi Bagging: {accuracy*100:.2f}%')

    return bagging_model
```

## 📄 Analisis Konten

### Implementasi Content Analysis:

```python
def check_phishing_content(url):
    """Analisis konten website untuk deteksi phishing"""
    try:
        # Ambil konten website
        response = requests.get(url, timeout=5)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Cek form password
        forms = soup.find_all('form')
        password_inputs = soup.find_all('input', {'type': 'password'})

        # Cek script mencurigakan
        scripts = soup.find_all('script')
        suspicious_scripts = []

        for script in scripts:
            if 'eval(' in script.text or 'document.cookie' in script.text:
                suspicious_scripts.append(script.text)

        # Analisis hasil
        risk_score = 0
        reasons = []

        if len(password_inputs) > 0:
            risk_score += 30
            reasons.append("Form password terdeteksi")

        if len(suspicious_scripts) > 0:
            risk_score += 40
            reasons.append("Script mencurigakan terdeteksi")

        return {
            'risk_score': risk_score,
            'reasons': reasons,
            'is_phishing': risk_score > 50
        }

    except Exception as e:
        return {
            'risk_score': 0,
            'reasons': [f"Error: {str(e)}"],
            'is_phishing': False
        }
```

## 🔄 Workflow Sistem

### 1. Input URL

```python
url = "https://example.com"
```

### 2. Feature Extraction

```python
features = generate_data_set(url)  # 30 fitur
```

### 3. Content Analysis

```python
content_result = check_phishing_content(url)
```

### 4. ML Prediction

```python
# Load model
model = load_model()

# Predict
ml_prediction = model.predict([features])[0]
ml_probability = model.predict_proba([features])[0]
```

### 5. Combine Results

```python
def get_final_result(ml_result, content_result):
    # Weighted decision
    ml_weight = 0.7
    content_weight = 0.3

    final_score = (ml_result * ml_weight) + (content_result * content_weight)

    if final_score > 0.5:
        return "Website phishing"
    else:
        return "Bukan website phishing"
```

## 📊 Evaluasi Model

### Metrics yang Digunakan:

1. **Accuracy**: `(TP + TN) / (TP + TN + FP + FN)`
2. **Precision**: `TP / (TP + FP)`
3. **Recall**: `TP / (TP + FN)`
4. **F1-Score**: `2 × (Precision × Recall) / (Precision + Recall)`

### Implementasi Evaluasi:

```python
from sklearn.metrics import classification_report, confusion_matrix

def evaluate_model(model, X_test, y_test):
    # Prediksi
    y_pred = model.predict(X_test)

    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred)
    print("Confusion Matrix:")
    print(cm)

    # Classification Report
    report = classification_report(y_test, y_pred)
    print("Classification Report:")
    print(report)

    # Accuracy
    accuracy = model.score(X_test, y_test)
    print(f"Accuracy: {accuracy*100:.2f}%")
```

## 🚀 Penggunaan

### 1. Training Model:

```python
# Load dataset
df = pd.read_csv("dataset_pi.csv")
X = df.iloc[:, :-1]  # Features
y = df.iloc[:, -1]   # Labels

# Train model
model = train_bagging_model(X, y, n_estimators=100)

# Save model
save_model(model)
```

### 2. Prediction:

```python
# Load model
model = load_model()

# Extract features
url = "https://suspicious-site.com"
features = generate_data_set(url)

# Predict
result = model.predict([features])
probability = model.predict_proba([features])

print(f"Prediction: {result[0]}")
print(f"Probability: {probability[0]}")
```

### 3. Integration dengan Web:

```python
def getResult(url):
    # Feature extraction
    features = generate_data_set(url)

    # Content analysis
    content_result = check_phishing_content(url)

    # ML prediction
    model = load_model()
    ml_result = model.predict([features])[0]

    # Combine results
    final_result = get_final_result(ml_result, content_result)

    return final_result
```

## 📈 Keunggulan Implementasi Ini

1. **Robust**: Menggunakan ensemble learning (Bagging)
2. **Comprehensive**: Kombinasi ML + Content Analysis
3. **Scalable**: Mudah ditambahkan fitur baru
4. **Interpretable**: Decision Tree mudah dipahami
5. **Real-time**: Prediksi cepat untuk URL baru

## 🔧 Optimasi

### Hyperparameter Tuning:

```python
from sklearn.model_selection import GridSearchCV

param_grid = {
    'n_estimators': [50, 100, 200],
    'max_samples': [0.7, 0.8, 1.0],
    'max_features': [0.7, 0.8, 1.0]
}

grid_search = GridSearchCV(
    BaggingClassifier(DecisionTreeClassifier()),
    param_grid,
    cv=5,
    scoring='accuracy'
)

grid_search.fit(X_train, y_train)
best_model = grid_search.best_estimator_
```

Implementasi ini memberikan sistem deteksi phishing yang robust, akurat, dan mudah dipahami dengan kombinasi Decision Tree dan Bagging ensemble learning.
