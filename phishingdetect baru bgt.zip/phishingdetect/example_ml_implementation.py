"""
Contoh Implementasi Praktis Machine Learning Decision Tree & Bagging
untuk Deteksi Phishing Website
"""

import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import pickle
import re
import requests
from bs4 import BeautifulSoup
import whois
from datetime import datetime

class PhishingDetector:
    def __init__(self):
        self.model = None
        self.feature_names = [
            'Having_IP_Address', 'URL_Length', 'Shortining_Service', 'Having_At_Symbol',
            'Double_Slash_Redirecting', 'Prefix_Suffix', 'Having_Sub_Domain',
            'SSLfinal_State', 'Domain_registeration_length', 'Favicon', 'Port',
            'HTTPS_token', 'Request_URL', 'URL_of_Anchor', 'Links_in_tags',
            'SFH', 'Submitting_to_email', 'Abnormal_URL', 'Redirect', 'on_mouseover',
            'RightClick', 'popUpWidnow', 'Iframe', 'age_of_domain', 'DNSRecord',
            'web_traffic', 'Page_Rank', 'Google_Index', 'Links_pointing_to_page',
            'Statistical_report'
        ]
    
    def extract_features(self, url):
        """Ekstraksi 30 fitur dari URL"""
        features = []
        
        # Normalisasi URL
        if not re.match(r"^https?", url):
            url = "http://" + url
        
        try:
            # Ekstraksi domain
            domain = re.findall(r"://([^/]+)/?", url)[0]
            if re.match(r"^www.", domain):
                domain = domain.replace("www.", "")
        except:
            domain = ""
        
        # 1. Having_IP_Address
        features.append(1 if re.match(r"^\d+\.\d+\.\d+\.\d+", domain) else -1)
        
        # 2. URL_Length
        features.append(1 if len(url) > 75 else -1)
        
        # 3. Shortining_Service
        shorteners = ['bit.ly', 'goo.gl', 'tinyurl.com', 't.co', 'is.gd']
        features.append(1 if any(s in url for s in shorteners) else -1)
        
        # 4. Having_At_Symbol
        features.append(1 if '@' in url else -1)
        
        # 5. Double_Slash_Redirecting
        features.append(1 if '//' in url[8:] else -1)
        
        # 6. Prefix_Suffix
        features.append(1 if '-' in domain else -1)
        
        # 7. Having_Sub_Domain
        subdomain_count = len(domain.split('.')) - 1
        features.append(1 if subdomain_count > 2 else -1)
        
        # 8. SSLfinal_State
        features.append(1 if url.startswith('https') else -1)
        
        # 9. Domain_registeration_length
        try:
            w = whois.whois(domain)
            if w.creation_date:
                if isinstance(w.creation_date, list):
                    creation_date = w.creation_date[0]
                else:
                    creation_date = w.creation_date
                age_months = (datetime.now() - creation_date).days / 30
                features.append(1 if age_months < 6 else -1)
            else:
                features.append(-1)
        except:
            features.append(-1)
        
        # 10. Favicon
        try:
            response = requests.get(url, timeout=5)
            soup = BeautifulSoup(response.text, 'html.parser')
            favicon = soup.find('link', rel='icon') or soup.find('link', rel='shortcut icon')
            features.append(1 if favicon else -1)
        except:
            features.append(-1)
        
        # 11. Port
        features.append(1 if ':80' in url or ':443' in url else -1)
        
        # 12. HTTPS_token
        features.append(1 if 'https' in domain else -1)
        
        # 13. Request_URL
        try:
            response = requests.get(url, timeout=5)
            soup = BeautifulSoup(response.text, 'html.parser')
            external_links = soup.find_all('a', href=True)
            external_count = sum(1 for link in external_links if domain not in link['href'])
            features.append(1 if external_count > 0 else -1)
        except:
            features.append(-1)
        
        # 14. URL_of_Anchor
        features.append(1 if '#' in url else -1)
        
        # 15. Links_in_tags
        try:
            response = requests.get(url, timeout=5)
            soup = BeautifulSoup(response.text, 'html.parser')
            links = soup.find_all('a')
            features.append(1 if len(links) > 20 else -1)
        except:
            features.append(-1)
        
        # 16. SFH (Server Form Handler)
        try:
            response = requests.get(url, timeout=5)
            soup = BeautifulSoup(response.text, 'html.parser')
            forms = soup.find_all('form')
            if forms:
                action = forms[0].get('action', '')
                features.append(1 if action == '' or action == 'about:blank' else -1)
            else:
                features.append(-1)
        except:
            features.append(-1)
        
        # 17. Submitting_to_email
        try:
            response = requests.get(url, timeout=5)
            soup = BeautifulSoup(response.text, 'html.parser')
            forms = soup.find_all('form')
            if forms:
                action = forms[0].get('action', '')
                features.append(1 if 'mailto:' in action else -1)
            else:
                features.append(-1)
        except:
            features.append(-1)
        
        # 18. Abnormal_URL
        features.append(1 if domain not in url else -1)
        
        # 19. Redirect
        try:
            response = requests.get(url, timeout=5, allow_redirects=False)
            features.append(1 if response.status_code in [301, 302] else -1)
        except:
            features.append(-1)
        
        # 20. on_mouseover
        try:
            response = requests.get(url, timeout=5)
            features.append(1 if 'onmouseover' in response.text else -1)
        except:
            features.append(-1)
        
        # 21. RightClick
        try:
            response = requests.get(url, timeout=5)
            features.append(1 if 'oncontextmenu' in response.text else -1)
        except:
            features.append(-1)
        
        # 22. popUpWidnow
        try:
            response = requests.get(url, timeout=5)
            features.append(1 if 'popup' in response.text.lower() else -1)
        except:
            features.append(-1)
        
        # 23. Iframe
        try:
            response = requests.get(url, timeout=5)
            features.append(1 if '<iframe' in response.text else -1)
        except:
            features.append(-1)
        
        # 24. age_of_domain
        try:
            w = whois.whois(domain)
            if w.creation_date:
                if isinstance(w.creation_date, list):
                    creation_date = w.creation_date[0]
                else:
                    creation_date = w.creation_date
                age_days = (datetime.now() - creation_date).days
                features.append(1 if age_days < 365 else -1)
            else:
                features.append(-1)
        except:
            features.append(-1)
        
        # 25. DNSRecord
        try:
            import socket
            socket.gethostbyname(domain)
            features.append(-1)  # DNS record exists
        except:
            features.append(1)   # No DNS record
        
        # 26. web_traffic
        features.append(-1)  # Default value, would need external API
        
        # 27. Page_Rank
        features.append(-1)  # Default value, would need external API
        
        # 28. Google_Index
        features.append(-1)  # Default value, would need external API
        
        # 29. Links_pointing_to_page
        features.append(-1)  # Default value, would need external API
        
        # 30. Statistical_report
        features.append(-1)  # Default value, would need external API
        
        return features
    
    def train_model(self, dataset_path):
        """Melatih model dengan dataset"""
        try:
            # Load dataset
            df = pd.read_csv(dataset_path)
            X = df.iloc[:, :-1]  # Features
            y = df.iloc[:, -1]   # Labels
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Buat Bagging Classifier dengan Decision Tree
            self.model = BaggingClassifier(
                base_estimator=DecisionTreeClassifier(random_state=42),
                n_estimators=100,
                max_samples=1.0,
                max_features=1.0,
                random_state=42
            )
            
            # Training
            print("Melatih model...")
            self.model.fit(X_train, y_train)
            
            # Evaluasi
            y_pred = self.model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            
            print(f"Akurasi Model: {accuracy*100:.2f}%")
            print("\nClassification Report:")
            print(classification_report(y_test, y_pred))
            
            # Cross validation
            cv_scores = cross_val_score(self.model, X, y, cv=5)
            print(f"\nCross Validation Scores: {cv_scores}")
            print(f"CV Mean: {cv_scores.mean():.3f} (+/- {cv_scores.std() * 2:.3f})")
            
            return True
            
        except Exception as e:
            print(f"Error saat training: {e}")
            return False
    
    def predict(self, url):
        """Prediksi phishing untuk URL"""
        if self.model is None:
            return "Model belum dilatih"
        
        try:
            # Ekstraksi fitur
            features = self.extract_features(url)
            
            # Prediksi
            prediction = self.model.predict([features])[0]
            probability = self.model.predict_proba([features])[0]
            
            result = {
                'url': url,
                'prediction': 'Phishing' if prediction == 1 else 'Legitimate',
                'confidence': max(probability) * 100,
                'features': dict(zip(self.feature_names, features))
            }
            
            return result
            
        except Exception as e:
            return f"Error saat prediksi: {e}"
    
    def save_model(self, filename='phishing_model.pkl'):
        """Menyimpan model"""
        if self.model is not None:
            with open(filename, 'wb') as f:
                pickle.dump(self.model, f)
            print(f"Model disimpan sebagai {filename}")
        else:
            print("Model belum dilatih")
    
    def load_model(self, filename='phishing_model.pkl'):
        """Memuat model"""
        try:
            with open(filename, 'rb') as f:
                self.model = pickle.load(f)
            print(f"Model dimuat dari {filename}")
            return True
        except Exception as e:
            print(f"Error saat memuat model: {e}")
            return False

def main():
    """Contoh penggunaan"""
    detector = PhishingDetector()
    
    # Contoh 1: Training model (jika ada dataset)
    # detector.train_model('dataset_pi.csv')
    # detector.save_model()
    
    # Contoh 2: Load model yang sudah ada
    if detector.load_model():
        # Test URLs
        test_urls = [
            "https://google.com",
            "https://facebook.com",
            "https://suspicious-phishing-site.com",
            "http://192.168.1.1",
            "https://bit.ly/suspicious-link"
        ]
        
        print("\n=== HASIL PREDIKSI ===")
        for url in test_urls:
            result = detector.predict(url)
            print(f"\nURL: {result['url']}")
            print(f"Prediksi: {result['prediction']}")
            print(f"Confidence: {result['confidence']:.2f}%")
            
            # Tampilkan beberapa fitur penting
            important_features = ['Having_IP_Address', 'URL_Length', 'Shortining_Service', 'SSLfinal_State']
            print("Fitur Penting:")
            for feature in important_features:
                if feature in result['features']:
                    value = "Ya" if result['features'][feature] == 1 else "Tidak"
                    print(f"  {feature}: {value}")

if __name__ == "__main__":
    main() 