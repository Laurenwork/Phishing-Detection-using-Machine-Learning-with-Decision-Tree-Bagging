-- File untuk memperbaiki struktur database Phishingdetect
USE phishingdetect;

-- Hapus tabel riwayat jika ada
DROP TABLE IF EXISTS riwayat;

-- Hapus tabel users jika ada
DROP TABLE IF EXISTS users;

-- Buat ulang tabel users
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Buat ulang tabel riwayat dengan foreign key yang benar
CREATE TABLE riwayat (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  url VARCHAR(500) NOT NULL,
  hasil VARCHAR(100) NOT NULL,
  waktu DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tambah index untuk performa
CREATE INDEX idx_riwayat_user_id ON riwayat(user_id);
CREATE INDEX idx_riwayat_waktu ON riwayat(waktu);

-- Masukkan user admin default (password: admin123)
INSERT INTO users (username, email, password, role) VALUES 
('admin', 'admin@phishingdetect.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Masukkan beberapa user test (password: test123)
INSERT INTO users (username, email, password, role) VALUES 
('user1', 'user1@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user'),
('user2', 'user2@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user');

-- Masukkan beberapa data riwayat test
INSERT INTO riwayat (user_id, url, hasil) VALUES 
(2, 'https://google.com', 'Bukan website phishing'),
(2, 'https://facebook.com', 'Bukan website phishing'),
(3, 'https://suspicious-site.com', 'Website phishing'),
(3, 'https://youtube.com', 'Bukan website phishing');

-- Tampilkan struktur tabel
DESCRIBE users;
DESCRIBE riwayat;

-- Tampilkan data
SELECT * FROM users;
SELECT * FROM riwayat; 