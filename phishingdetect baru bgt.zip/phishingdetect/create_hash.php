<?php
// File untuk menghasilkan hash password yang benar
$password = 'lauren123';
$hash = password_hash($password, PASSWORD_DEFAULT);
echo "Password: " . $password . "<br>";
echo "Hash: " . $hash . "<br>";
echo "<br>Copy hash di atas ke file fix_database_username.sql<br>";

// Test verifikasi
if (password_verify($password, $hash)) {
    echo "✅ Hash password valid!";
} else {
    echo "❌ Hash password tidak valid!";
}
?> 