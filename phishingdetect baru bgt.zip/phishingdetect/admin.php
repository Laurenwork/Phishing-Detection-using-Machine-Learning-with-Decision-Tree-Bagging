<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: auth.php');
    exit();
}
require 'config.php';

// Handle delete user
if (isset($_POST['delete_user'])) {
    $username = $conn->real_escape_string($_POST['username']);
    try {
        $conn->query("DELETE FROM riwayat WHERE username = '$username'");
        $conn->query("DELETE FROM users WHERE username = '$username'");
    } catch (Exception $e) {
        error_log("Error deleting user: " . $e->getMessage());
    }
    header('Location: admin.php');
    exit();
}

// Handle delete history
if (isset($_POST['delete_history'])) {
    $history_id = (int)$_POST['history_id'];
    try {
        $conn->query("DELETE FROM riwayat WHERE id_url = $history_id");
    } catch (Exception $e) {
        error_log("Error deleting history: " . $e->getMessage());
    }
    header('Location: admin.php');
    exit();
}

try {
    $users = $conn->query("SELECT id_users AS id, username, email, role, (SELECT COUNT(*) FROM riwayat WHERE username = users.username) as total_searches FROM users ORDER BY id_users");
    $riwayat = $conn->query("SELECT r.*, r.username FROM riwayat r ORDER BY r.waktu DESC");
} catch (Exception $e) {
    error_log("Database error in admin.php: " . $e->getMessage());
    $users = null;
    $riwayat = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - PhishingDetect</title>
    <link rel="stylesheet" href="static/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <script src="static/theme.js"></script>
    <style>
        .admin-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .admin-section {
            margin-bottom: 40px;
        }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .admin-table th {
            background: #2563eb;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        .admin-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        .admin-table tr:hover {
            background: #f8f9fa;
        }
        .delete-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            transition: background 0.3s;
        }
        .delete-btn:hover {
            background: #c82333;
        }
        .user-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            font-weight: bold;
        }
        .user-badge.admin {
            background: #ffc107;
            color: #000;
        }
        .user-badge.user {
            background: #17a2b8;
            color: white;
        }
        .search-count {
            background: #28a745;
            color: white;
            padding: 2px 6px;
            border-radius: 10px;
            font-size: 0.8em;
            font-weight: bold;
        }
        .admin-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .admin-header h1 {
            color: #2563eb;
            margin-bottom: 10px;
        }
        .admin-header p {
            color: #fff !important;
            font-size: 1.1em;
            text-shadow: 0 2px 8px rgba(0,0,0,0.3);
            background: rgba(0,0,0,0.2);
            padding: 8px 16px;
            border-radius: 20px;
            display: inline-block;
            backdrop-filter: blur(10px);
        }
        
        /* Style khusus untuk subtitle di halaman admin */
        .admin-header p.login-subtitle {
            color: #fff !important;
            text-shadow: 0 2px 8px rgba(0,0,0,0.3);
            background: rgba(0,0,0,0.2);
            padding: 8px 16px;
            border-radius: 20px;
            display: inline-block;
            backdrop-filter: blur(10px);
            font-weight: 500;
        }


    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <header class="animate__animated animate__fadeIn">
        <h1><i class="fas fa-user-shield"></i> Admin Panel</h1>
        <p class="login-subtitle">Kelola user dan pantau aktivitas deteksi phishing</p>
    </header>
    
    <div class="container">
        <div class="admin-header animate__animated animate__fadeInUp">
            <h2 style="color:#2563eb;text-align:center;margin-bottom:20px;">
                <i class="fas fa-chart-bar"></i> Dashboard Statistik
            </h2>
        </div>

        <!-- Statistics Cards -->
        <div class="admin-stats animate__animated animate__fadeInUp">
            <?php
            $total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
            $total_searches = $conn->query("SELECT COUNT(*) as count FROM riwayat")->fetch_assoc()['count'];
            $total_admins = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'")->fetch_assoc()['count'];
            $today_searches = $conn->query("SELECT COUNT(*) as count FROM riwayat WHERE DATE(waktu) = CURDATE()")->fetch_assoc()['count'];
            ?>
            <div class="stat-card">
                <div class="stat-number"><?= $total_users ?></div>
                <div>Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $total_searches ?></div>
                <div>Total Deteksi</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $total_admins ?></div>
                <div>Admin Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $today_searches ?></div>
                <div>Deteksi Hari Ini</div>
            </div>
        </div>

        <!-- Users Section -->
        <div class="admin-section animate__animated animate__fadeInUp">
            <div class="card">
                <h2><i class="fas fa-users"></i> Daftar User Terdaftar</h2>
                <div style="overflow-x: auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID User</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Total Deteksi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $users->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['id'] ?></td>
                                <td><strong><?= htmlspecialchars($row['username']) ?></strong></td>
                                <td><?= htmlspecialchars($row['email']) ?></td>
                                <td>
                                    <span class="user-badge <?= $row['role'] ?>">
                                        <?= ucfirst($row['role']) ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="search-count"><?= $row['total_searches'] ?></span>
                                </td>
                                <td>
                                    <?php if ($row['username'] != $_SESSION['username']): ?>
                                    <form method="post" style="display: inline;" onsubmit="return confirm('Yakin ingin menghapus user <?= htmlspecialchars($row['username']) ?>? Semua riwayat user ini akan dihapus.')">
                                        <input type="hidden" name="username" value="<?= htmlspecialchars($row['username']) ?>">
                                        <button type="submit" name="delete_user" class="delete-btn">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                    </form>
                                    <?php else: ?>
                                    <span style="color: #999; font-style: italic;">Current User</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- History Section -->
        <div class="admin-section animate__animated animate__fadeInUp">
            <div class="card">
                <h2><i class="fas fa-history"></i> Riwayat Deteksi Semua User</h2>
                <div style="overflow-x: auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>User</th>
                                <th>URL</th>
                                <th>Hasil</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $riwayat->fetch_assoc()): 
                                $hasil = strtolower($row['hasil']);
                                $is_safe = strpos($hasil, 'bukan website phishing') !== false;
                                $is_phishing = strpos($hasil, 'phishing') !== false && !$is_safe;
                                $badge_class = $is_safe ? 'safe' : ($is_phishing ? 'phishing' : 'neutral');
                            ?>
                            <tr>
                                <td>
                                    <div style="font-weight: bold;"><?= date('d M Y', strtotime($row['waktu'])) ?></div>
                                    <div style="font-size: 0.9em; color: #666;"><?= date('H:i:s', strtotime($row['waktu'])) ?></div>
                                </td>
                                <td><strong><?= htmlspecialchars($row['username']) ?></strong></td>
                                <td style="max-width: 300px; word-wrap: break-word;">
                                    <?= htmlspecialchars($row['url']) ?>
                                </td>
                                <td>
                                    <span class="history-result <?= $badge_class ?>">
                                        <?= htmlspecialchars($row['hasil']) ?>
                                    </span>

                                </td>
                                <td>
                                    <form method="post" style="display: inline;" onsubmit="return confirm('Yakin ingin menghapus riwayat ini?')">
                                        <input type="hidden" name="history_id" value="<?= $row['id_url'] ?>">
                                        <button type="submit" name="delete_history" class="delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>



    <script>
        // Add confirmation for delete actions
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (!confirm('Yakin ingin menghapus item ini?')) {
                    e.preventDefault();
                }
            });
        });


    </script>
</body>
</html> 