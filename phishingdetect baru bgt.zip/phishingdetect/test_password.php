<?php
// Test password lauren123
$password = 'lauren123';
$hash = password_hash($password, PASSWORD_DEFAULT);

echo "Password: " . $password . "<br>";
echo "Hash: " . $hash . "<br>";

// Test verifikasi
if (password_verify($password, $hash)) {
    echo "✅ Password valid!<br>";
} else {
    echo "❌ Password tidak valid!<br>";
}

// Test dengan hash yang ada di database
$db_hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
if (password_verify($password, $db_hash)) {
    echo "✅ Hash database valid untuk lauren123!<br>";
} else {
    echo "❌ Hash database tidak valid untuk lauren123!<br>";
}
?> 