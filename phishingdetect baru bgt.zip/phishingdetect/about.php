<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - PhishingDetect</title>
    <link rel="stylesheet" href="static/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <!-- Hero Section dengan Background Image -->
    <div class="hero-section animate__animated animate__fadeIn">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <div class="hero-logo">
                <div class="logo-container">
                    <i class="fas fa-shield-alt logo-icon"></i>
                    <div class="logo-text">
                        <h1 class="hero-title">PhishingDetect</h1>
                        <p class="hero-subtitle">Platform Deteksi Phishing</p>
                    </div>
                </div>
            </div>
            <div class="hero-description">
                <p>Menggunakan teknologi <strong>Machine Learning</strong> dengan algoritma <strong>Decision Tree & Bagging</strong> untuk mendeteksi website phishing secara akurat dan real-time.</p>
            </div>
        </div>
    </div>
    
    <div class="container">
        <!-- Section Apa itu Phishing -->
        <div class="card animate__animated animate__fadeInUp" style="margin-bottom:30px;">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="section-content">
                    <h2 style="color:var(--accent-color);margin-bottom:20px;text-align:center;">Apa itu Phishing?</h2>
                    <p style="font-size:1.1em;line-height:1.8;color:var(--text-primary);text-align:center;max-width:800px;margin:0 auto 25px auto;">
                        <strong>Phishing</strong> adalah upaya penipuan dengan cara mengelabui korban agar memberikan informasi sensitif seperti password, data kartu kredit, atau data penting lainnya melalui website palsu yang menyerupai website resmi. Phishing seringkali sulit dikenali karena tampilannya sangat mirip dengan website asli.
                    </p>
                    <div class="phishing-example">
                        <div class="example-item">
                            <i class="fas fa-times-circle text-danger"></i>
                            <span>Website palsu: <code>paypa1.com</code></span>
                        </div>
                        <div class="example-item">
                            <i class="fas fa-check-circle text-success"></i>
                            <span>Website asli: <code>paypal.com</code></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Bagaimana Mendeteksi -->
        <div class="card animate__animated animate__fadeInUp" style="margin-bottom:30px;">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <div class="section-content">
                    <h2 style="color:var(--accent-color);margin-bottom:20px;text-align:center;">Bagaimana Website Ini Mendeteksi Phishing?</h2>
                    <p style="font-size:1.1em;line-height:1.8;color:var(--text-primary);text-align:center;max-width:800px;margin:0 auto 25px auto;">
                        Website ini menggunakan <strong>Machine Learning</strong> (Decision Tree & Bagging) dan analisis fitur URL serta konten website untuk mendeteksi potensi phishing. Sistem menganalisis panjang URL, karakter mencurigakan, umur domain, penggunaan IP, SSL, dan banyak fitur lain secara otomatis.
                    </p>
                    <div class="detection-methods">
                        <div class="method-item">
                            <i class="fas fa-link"></i>
                            <span>Analisis URL & Domain</span>
                        </div>
                        <div class="method-item">
                            <i class="fas fa-code"></i>
                            <span>Analisis Konten Website</span>
                        </div>
                        <div class="method-item">
                            <i class="fas fa-robot"></i>
                            <span>Machine Learning Model</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Teknologi yang Digunakan -->
        <div class="card animate__animated animate__fadeInUp" style="margin-bottom:30px;">
            <h2 style="color:var(--accent-color);margin-bottom:30px;text-align:center;font-size:1.4em;">
                <i class="fas fa-cogs"></i> Teknologi yang Digunakan
            </h2>
            <div class="tech-grid">
                <!-- Row 1 - Bergerak dari atas ke kiri -->
                <div class="tech-badge tech-left" data-delay="0.1">
                    <div class="tech-icon">
                        <i class="fab fa-python"></i>
                    </div>
                    <span class="tech-name">Python</span>
                </div>
                
                <div class="tech-badge tech-left" data-delay="0.2">
                    <div class="tech-icon">
                        <i class="fab fa-php"></i>
                    </div>
                    <span class="tech-name">PHP</span>
                </div>
                
                <div class="tech-badge tech-left" data-delay="0.3">
                    <div class="tech-icon">
                        <i class="fas fa-database"></i>
                    </div>
                    <span class="tech-name">MySQL</span>
                </div>
                
                <div class="tech-badge tech-left" data-delay="0.4">
                    <div class="tech-icon">
                        <i class="fab fa-js"></i>
                    </div>
                    <span class="tech-name">JavaScript</span>
                </div>
                
                <div class="tech-badge tech-left" data-delay="0.5">
                    <div class="tech-icon">
                        <i class="fab fa-html5"></i>
                    </div>
                    <span class="tech-name">HTML5</span>
                </div>
                
                <div class="tech-badge tech-left" data-delay="0.6">
                    <div class="tech-icon">
                        <i class="fab fa-css3-alt"></i>
                    </div>
                    <span class="tech-name">CSS3</span>
                </div>
                
                <!-- Row 2 - Bergerak dari bawah ke kanan -->
                <div class="tech-badge tech-right" data-delay="0.7">
                    <div class="tech-icon">
                        <i class="fas fa-brain"></i>
                    </div>
                    <span class="tech-name">Machine Learning</span>
                </div>
                
                <div class="tech-badge tech-right" data-delay="0.8">
                    <div class="tech-icon">
                        <i class="fas fa-sitemap"></i>
                    </div>
                    <span class="tech-name">Decision Tree</span>
                </div>
                
                <div class="tech-badge tech-right" data-delay="0.9">
                    <div class="tech-icon">
                        <i class="fas fa-layer-group"></i>
                    </div>
                    <span class="tech-name">Bagging</span>
                </div>
                
                <div class="tech-badge tech-right" data-delay="1.0">
                    <div class="tech-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <span class="tech-name">Feature Extraction</span>
                </div>
                
                <div class="tech-badge tech-right" data-delay="1.1">
                    <div class="tech-icon">
                        <i class="fas fa-code"></i>
                    </div>
                    <span class="tech-name">Content Analysis</span>
                </div>
                
                <div class="tech-badge tech-right" data-delay="1.2">
                    <div class="tech-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <span class="tech-name">Security</span>
                </div>
            </div>
        </div>

        <!-- Section Keunggulan -->
        <div class="card animate__animated animate__fadeInUp" style="background:var(--bg-secondary);max-width:1000px;margin:0 auto 30px auto;border:2px solid var(--accent-color);padding:40px;">
            <h2 style="color:var(--accent-color);margin-bottom:30px;font-size:1.4em;text-align:center;">
                <i class="fas fa-star"></i> Kenapa Harus Menggunakan Website Kami?
            </h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:25px;justify-items:center;">
                <div class="point-card blue-card">
                    <i class="fas fa-bolt"></i>
                    <div class="point-title">Deteksi otomatis & cepat tanpa install aplikasi</div>
                </div>
                <div class="point-card blue-card">
                    <i class="fas fa-robot"></i>
                    <div class="point-title">Menggunakan teknologi Machine Learning terkini</div>
                </div>
                <div class="point-card blue-card">
                    <i class="fas fa-history"></i>
                    <div class="point-title">Riwayat pencarian tersimpan & bisa dipantau</div>
                </div>
                <div class="point-card blue-card">
                    <i class="fas fa-gift"></i>
                    <div class="point-title">Gratis & mudah digunakan siapa saja</div>
                </div>
                <div class="point-card blue-card">
                    <i class="fas fa-lock"></i>
                    <div class="point-title">Data Anda aman, tidak disimpan untuk tujuan lain</div>
                </div>
                <div class="point-card blue-card">
                    <i class="fas fa-chart-line"></i>
                    <div class="point-title">Statistik real-time & laporan detail</div>
                </div>
            </div>
        </div>

        <!-- Section Cara Mencegah Phishing -->
        <div class="card animate__animated animate__fadeInUp" style="background:var(--bg-secondary);max-width:1000px;margin:0 auto 30px auto;border:2px solid #dc2626;padding:40px;">
            <h2 style="color:#dc2626;margin-bottom:30px;font-size:1.4em;text-align:center;">
                <i class="fas fa-shield-alt"></i> Cara Mencegah Phishing
            </h2>
            <p style="text-align:center;margin-bottom:30px;font-size:1.1em;color:var(--text-secondary);max-width:800px;margin-left:auto;margin-right:auto;">
                Berdasarkan data keamanan siber, <strong>91% serangan siber dimulai dengan email phishing</strong>. 
                Berikut adalah tips praktis untuk melindungi diri Anda:
            </p>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:25px;justify-items:center;">
                <div class="prevention-card">
                    <div class="prevention-icon">
                        <i class="fas fa-link"></i>
                    </div>
                    <h3>Periksa URL dengan Teliti</h3>
                    <p>Jangan klik link sembarangan. Periksa domain dengan cermat. Contoh: <code>paypa1.com</code> (bukan paypal.com) atau <code>g00gle.com</code> (bukan google.com).</p>
                </div>
                
                <div class="prevention-card">
                    <div class="prevention-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h3>Waspadai Email Mencurigakan</h3>
                    <p>Email dari bank yang meminta data pribadi, hadiah mengejutkan, atau ancaman mendesak adalah tanda phishing. Bank resmi tidak pernah meminta password via email.</p>
                </div>
                
                <div class="prevention-card">
                    <div class="prevention-icon">
                        <i class="fas fa-lock"></i>
                    </div>
                    <h3>Gunakan Two-Factor Authentication</h3>
                    <p>Aktifkan 2FA di semua akun penting. Meskipun password bocor, pelaku tidak bisa mengakses akun tanpa kode verifikasi tambahan.</p>
                </div>
                
                <div class="prevention-card">
                    <div class="prevention-icon">
                        <i class="fas fa-download"></i>
                    </div>
                    <h3>Jangan Download File Mencurigakan</h3>
                    <p>File .exe, .zip, atau lampiran email yang tidak diharapkan bisa mengandung malware. Selalu scan file sebelum membuka.</p>
                </div>
                
                <div class="prevention-card">
                    <div class="prevention-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <h3>Jangan Bagikan Data Sensitif</h3>
                    <p>Password, PIN, nomor kartu kredit, atau OTP tidak boleh dibagikan kepada siapapun, termasuk yang mengaku dari bank atau layanan resmi.</p>
                </div>
                
                <div class="prevention-card">
                    <div class="prevention-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3>Waspadai SMS Phishing</h3>
                    <p>Link dalam SMS bisa berbahaya. Jika mendapat SMS dari nomor tidak dikenal dengan link, jangan diklik. Hubungi layanan pelanggan resmi.</p>
                </div>
            </div>
            
            <div class="fact-box">
                <h4 style="color:#92400e;margin:0 0 15px 0;text-align:center;">
                    <i class="fas fa-exclamation-triangle"></i> Fakta Penting:
                </h4>
                <ul style="margin:0;padding-left:20px;color:#92400e;max-width:600px;margin-left:auto;margin-right:auto;">
                    <li><strong>74% organisasi</strong> mengalami serangan phishing yang berhasil pada tahun 2023</li>
                    <li><strong>96% serangan phishing</strong> dilakukan melalui email</li>
                    <li><strong>Rata-rata kerugian</strong> akibat phishing mencapai $4.35 juta per organisasi</li>
                    <li><strong>Waktu terbaik</strong> untuk mendeteksi phishing adalah dalam 1 jam pertama</li>
                </ul>
            </div>
        </div>
    </div>
    
    <footer>
        <div class="footer-content">
            <div class="creator-info animate__animated animate__fadeIn">
                <p>Created by <span class="author-name">Laurensius Alessandro</span></p>
            </div>
            <div class="social-icons animate__animated animate__fadeIn">
                <a href="https://instagram.com/laurenaldr" target="_blank" class="social-icon">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="mailto:laurensandro9@gmail.com" class="social-icon">
                    <i class="far fa-envelope"></i>
                </a>
                <a href="https://github.com/Laurenwork" target="_blank" class="social-icon">
                    <i class="fab fa-github"></i>
                </a>
                <a href="https://www.linkedin.com/in/laurensius-alessandro/" target="_blank" class="social-icon">
                    <i class="fab fa-linkedin"></i>
                </a>
            </div>
            <p class="copyright">&copy; 2025 URL Phishing Detection. All rights reserved.</p>
        </div>
    </footer>
    
    <script src="static/theme.js"></script>
    <script>
        // Debug: Check if theme.js loaded
        console.log('About page loaded');
        if (typeof window.themeManager !== 'undefined') {
            console.log('Theme manager is available');
        } else {
            console.log('Theme manager not found');
        }

        // Tech badges animation
        function animateTechBadges() {
            const techBadges = document.querySelectorAll('.tech-badge');
            
            techBadges.forEach((badge, index) => {
                const delay = parseFloat(badge.getAttribute('data-delay')) * 1000;
                
                setTimeout(() => {
                    badge.classList.add('animate-in');
                }, delay);
            });
        }

        // Start animation when page loads
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(animateTechBadges, 500);
        });

        // Alternative: Start animation when section is visible
        function startAnimationWhenVisible() {
            const techSection = document.querySelector('.tech-grid');
            if (techSection) {
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            animateTechBadges();
                            observer.unobserve(entry.target);
                        }
                    });
                });
                observer.observe(techSection);
            }
        }

        // Use intersection observer if available
        if ('IntersectionObserver' in window) {
            startAnimationWhenVisible();
        } else {
            // Fallback for older browsers
            document.addEventListener('DOMContentLoaded', function() {
                setTimeout(animateTechBadges, 1000);
            });
        }
    </script>
</body>
</html> 