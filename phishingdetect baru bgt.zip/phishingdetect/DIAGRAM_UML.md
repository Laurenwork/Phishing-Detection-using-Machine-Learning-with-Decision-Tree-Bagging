# Diagram UML Website Phishing Detection

## 1. Activity Diagram

### Activity Diagram - User Perspective

```mermaid
graph TD
    A[User Mengakses Website] --> B{User Sudah Login?}
    B -->|Tidak| C[Tampilkan Halaman Home]
    B -->|Ya| D[Tampilkan Halaman Detect]

    C --> E[User Klik Menu Detect]
    E --> F{User Sudah Login?}
    F -->|Tidak| G[Redirect ke Login]
    F -->|Ya| D

    G --> H[User Login/Register]
    H --> I{Login Berhasil?}
    I -->|Tidak| H
    I -->|Ya| D

    D --> J[User Input URL]
    J --> K[Klik Analyze]
    K --> L[Proses Detection]
    L --> M[Feature Extraction]
    M --> N[Machine Learning Prediction]
    N --> O[Content Analysis]
    O --> P[Simpan ke Database]
    P --> Q[Tampilkan Hasil]
    Q --> R{Phishing?}
    R -->|Ya| S[Tampilkan Merah - Phishing]
    R -->|Tidak| T[Tampilkan Hijau - Aman]

    S --> U[User Klik Menu History]
    T --> U
    U --> V[Tampilkan Riwayat Detection]
    V --> W[User Logout]
    W --> X[Destroy Session]
    X --> C
```

### Activity Diagram - Admin Perspective

```mermaid
graph TD
    A[Admin Login] --> B{Login Berhasil?}
    B -->|Tidak| A
    B -->|Ya| C[Admin Panel]

    C --> D[Lihat Daftar User]
    C --> E[Lihat Riwayat Detection]
    C --> F[Kelola User]
    C --> G[Kelola Riwayat]

    D --> H[Tampilkan Tabel User]
    H --> I[Lihat Detail User]
    I --> J[Lihat Total Searches User]

    E --> K[Tampilkan Tabel Riwayat]
    K --> L[Lihat Detail Detection]
    L --> M[Lihat Alasan ML & Content Analysis]

    F --> N[Pilih User]
    N --> O[Delete User]
    O --> P{Konfirmasi Delete?}
    P -->|Ya| Q[Hapus User & Riwayatnya]
    P -->|Tidak| D

    G --> R[Pilih Riwayat]
    R --> S[Delete Riwayat]
    S --> T{Konfirmasi Delete?}
    T -->|Ya| U[Hapus Riwayat]
    T -->|Tidak| E

    Q --> C
    U --> C

    C --> V[Admin Logout]
    V --> W[Destroy Session]
    W --> X[Redirect ke Home]
```

## 2. Use Case Diagram

### Use Case Diagram - User

```mermaid
graph TD
    subgraph "User"
        U[User]
    end

    subgraph "System"
        UC1[Register]
        UC2[Login]
        UC3[Detect Phishing]
        UC4[View History]
        UC5[Logout]
        UC6[View Home Page]
    end

    subgraph "External System"
        ML[Machine Learning Model]
        CA[Content Analysis]
        DB[(Database)]
    end

    U --> UC1
    U --> UC2
    U --> UC3
    U --> UC4
    U --> UC5
    U --> UC6

    UC1 --> DB
    UC2 --> DB
    UC3 --> ML
    UC3 --> CA
    UC3 --> DB
    UC4 --> DB
```

### Use Case Diagram - Admin

```mermaid
graph TD
    subgraph "Admin"
        A[Admin]
    end

    subgraph "System"
        UC1[Login Admin]
        UC2[View All Users]
        UC3[View All History]
        UC4[Delete User]
        UC5[Delete History]
        UC6[View User Details]
        UC7[View Detection Details]
        UC8[Logout Admin]
    end

    subgraph "External System"
        DB[(Database)]
    end

    A --> UC1
    A --> UC2
    A --> UC3
    A --> UC4
    A --> UC5
    A --> UC6
    A --> UC7
    A --> UC8

    UC1 --> DB
    UC2 --> DB
    UC3 --> DB
    UC4 --> DB
    UC5 --> DB
    UC6 --> DB
    UC7 --> DB
```

## 3. Sequence Diagram

### Sequence Diagram - User Detection Process

```mermaid
sequenceDiagram
    participant U as User
    participant UI as User Interface
    participant PHP as PHP Backend
    participant PY as Python Script
    participant ML as ML Model
    participant DB as Database

    U->>UI: Input URL & Click Analyze
    UI->>PHP: Submit URL
    PHP->>PHP: Check Login Status
    PHP->>PY: Execute Detection Script
    PY->>PY: Feature Extraction
    PY->>ML: Load Decision Tree Model
    PY->>ML: Load Bagging Model
    PY->>PY: Content Analysis
    PY->>PHP: Return JSON Result
    PHP->>DB: Save Detection History
    PHP->>UI: Display Results
    UI->>U: Show Phishing/Aman Status
```

### Sequence Diagram - Admin Management

```mermaid
sequenceDiagram
    participant A as Admin
    participant UI as Admin Interface
    participant PHP as PHP Backend
    participant DB as Database

    A->>UI: Login Admin
    UI->>PHP: Submit Credentials
    PHP->>DB: Verify Admin
    DB->>PHP: Return Admin Status
    PHP->>UI: Redirect to Admin Panel

    A->>UI: View Users/History
    UI->>PHP: Request Data
    PHP->>DB: Query Users/History
    DB->>PHP: Return Data
    PHP->>UI: Display Tables

    A->>UI: Delete User/History
    UI->>PHP: Delete Request
    PHP->>DB: Execute Delete
    DB->>PHP: Confirm Deletion
    PHP->>UI: Update Display
    UI->>A: Show Updated Data
```

## 4. Class Diagram

### Class Diagram - System Architecture

```mermaid
classDiagram
    class User {
        +int id
        +string username
        +string email
        +string password
        +string role
        +datetime created_at
        +login()
        +logout()
        +register()
    }

    class DetectionHistory {
        +int id
        +string username
        +string url
        +string result
        +string ml_reason
        +string content_reason
        +datetime created_at
        +save()
        +getByUsername()
    }

    class PhishingDetector {
        +string url
        +dict features
        +string prediction
        +dict ml_details
        +dict content_details
        +extractFeatures()
        +predictML()
        +analyzeContent()
        +getResult()
    }

    class FeatureExtractor {
        +string url
        +dict features
        +extractURLFeatures()
        +extractDomainFeatures()
        +extractSSLFeatures()
    }

    class ContentAnalyzer {
        +string url
        +dict content_features
        +analyzeLoginForms()
        +analyzeBrandImpersonation()
        +analyzeSuspiciousScripts()
    }

    class MLModel {
        +DecisionTreeClassifier dt_model
        +BaggingClassifier bagging_model
        +loadModels()
        +predict()
        +getModelDetails()
    }

    class Database {
        +mysqli connection
        +connect()
        +query()
        +insert()
        +update()
        +delete()
        +close()
    }

    class Admin {
        +int id
        +string username
        +string email
        +string password
        +string role
        +viewAllUsers()
        +viewAllHistory()
        +deleteUser()
        +deleteHistory()
    }

    User ||--o{ DetectionHistory : "has"
    PhishingDetector --> FeatureExtractor : "uses"
    PhishingDetector --> ContentAnalyzer : "uses"
    PhishingDetector --> MLModel : "uses"
    User --> Database : "interacts with"
    Admin --> Database : "manages"
    DetectionHistory --> Database : "stored in"
```

### Class Diagram - Database Schema

```mermaid
classDiagram
    class users {
        +int id (PK)
        +varchar username
        +varchar email
        +varchar password
        +enum role
        +timestamp created_at
    }

    class riwayat {
        +int id (PK)
        +varchar username (FK)
        +text url
        +varchar result
        +text ml_reason
        +text content_reason
        +timestamp created_at
    }

    users ||--o{ riwayat : "has many"
```

## 5. Entity Relationship Diagram (ERD)

```mermaid
erDiagram
    USERS {
        int id PK
        varchar username UK
        varchar email UK
        varchar password
        enum role
        timestamp created_at
    }

    RIWAYAT {
        int id PK
        varchar username FK
        text url
        varchar result
        text ml_reason
        text content_reason
        timestamp created_at
    }

    USERS ||--o{ RIWAYAT : "user has many detections"
```

## 6. System Architecture Diagram

```mermaid
graph TB
    subgraph "Frontend Layer"
        UI[User Interface - HTML/CSS/JS]
        AUI[Admin Interface]
    end

    subgraph "Application Layer"
        PHP[PHP Backend]
        AUTH[Authentication]
        SESSION[Session Management]
    end

    subgraph "Business Logic Layer"
        DETECTOR[Phishing Detector]
        FE[Feature Extractor]
        CA[Content Analyzer]
        ML[ML Models]
    end

    subgraph "Data Layer"
        DB[(MySQL Database)]
        PKL[Pickle Models]
    end

    subgraph "External Services"
        WEB[Web Scraping]
        SSL[SSL Checker]
        WHOIS[WHOIS Lookup]
    end

    UI --> PHP
    AUI --> PHP
    PHP --> AUTH
    PHP --> SESSION
    PHP --> DETECTOR
    DETECTOR --> FE
    DETECTOR --> CA
    DETECTOR --> ML
    FE --> WEB
    FE --> SSL
    FE --> WHOIS
    ML --> PKL
    PHP --> DB
    AUTH --> DB
```

## 7. Data Flow Diagram

```mermaid
graph LR
    subgraph "Input"
        URL[URL Input]
        USER[User Credentials]
    end

    subgraph "Processing"
        FE[Feature Extraction]
        ML[ML Prediction]
        CA[Content Analysis]
        AUTH[Authentication]
    end

    subgraph "Output"
        RESULT[Detection Result]
        HISTORY[Search History]
        ADMIN[Admin Panel]
    end

    subgraph "Storage"
        DB[(Database)]
        MODELS[(ML Models)]
    end

    URL --> FE
    FE --> ML
    FE --> CA
    ML --> RESULT
    CA --> RESULT
    RESULT --> HISTORY
    HISTORY --> DB

    USER --> AUTH
    AUTH --> DB
    AUTH --> ADMIN

    ML --> MODELS
    FE --> MODELS
```

## Penjelasan Diagram

### 1. Activity Diagram

- **User Perspective**: Menunjukkan alur dari akses website hingga logout, termasuk proses detection dan pengecekan login status
- **Admin Perspective**: Menunjukkan alur manajemen user dan riwayat detection dari perspektif admin

### 2. Use Case Diagram

- **User**: Mendefinisikan fitur-fitur yang dapat diakses user (register, login, detect, view history, logout)
- **Admin**: Mendefinisikan fitur-fitur khusus admin (view users, delete users, view history, delete history)

### 3. Sequence Diagram

- **User Detection**: Menunjukkan interaksi antara user, PHP backend, Python script, ML model, dan database
- **Admin Management**: Menunjukkan alur manajemen data oleh admin

### 4. Class Diagram

- **System Architecture**: Mendefinisikan kelas-kelas utama sistem dan relasinya
- **Database Schema**: Menunjukkan struktur tabel database

### 5. Entity Relationship Diagram

- Menunjukkan relasi antara tabel users dan riwayat dengan foreign key username

### 6. System Architecture

- Menunjukkan layer-layer sistem dari frontend hingga data layer

### 7. Data Flow Diagram

- Menunjukkan alur data dari input hingga output dan storage

Semua diagram ini memberikan gambaran komprehensif tentang arsitektur dan alur kerja website phishing detection dari perspektif user dan admin.
