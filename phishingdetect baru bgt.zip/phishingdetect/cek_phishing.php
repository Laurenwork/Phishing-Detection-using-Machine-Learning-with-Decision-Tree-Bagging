<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: auth.php');
    exit();
}
require 'config.php';
$msg = '';
$hasil = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = trim($_POST['url']);
    if ($url) {
        $output = shell_exec("python phishing_detection.py " . escapeshellarg($url));
        $hasil = trim($output);
        $username = $_SESSION['username'];
        try {
            $stmt = $conn->prepare("INSERT INTO riwayat (username, url, hasil) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param('sss', $username, $url, $hasil);
                $stmt->execute();
            }
        } catch (Exception $e) {
            error_log("Error inserting riwayat in cek_phishing.php: " . $e->getMessage());
        }
        $msg = 'Hasil deteksi: ' . htmlspecialchars($hasil);
    } else {
        $msg = 'URL tidak boleh kosong!';
    }
}
?>
<?php include 'navbar.php'; ?>
<div class="container">
    <h2>Cek Link Phishing</h2>
    <form method="post">
        <input type="text" name="url" placeholder="Masukkan URL" required style="width:300px;">
        <button type="submit">Deteksi</button>
    </form>
    <p><?= $msg ?></p>
</div> 