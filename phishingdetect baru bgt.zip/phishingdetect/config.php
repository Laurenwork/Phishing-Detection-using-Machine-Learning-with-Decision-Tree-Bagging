<?php
// config.php
$host = 'localhost';
$db   = 'phishingdetect'; // Ganti sesuai nama database Anda
$user = 'root'; // Ganti sesuai user MySQL Anda
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die('Koneksi database gagal: ' . $conn->connect_error);
}
?> 