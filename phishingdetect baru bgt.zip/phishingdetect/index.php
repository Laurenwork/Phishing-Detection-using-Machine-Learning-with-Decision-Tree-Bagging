<?php
session_start();
require_once 'config.php';

// Jika user belum login dan submit form, redirect ke auth.php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_SESSION['user_id'])) {
    $_SESSION['flash_msg'] = 'Silakan login terlebih dahulu untuk melakukan deteksi.';
    header('Location: auth.php');
    exit();
}

// Proses deteksi jika form disubmit dan user sudah login
$deteksi_hasil = '';
$deteksi_detail = null;
$deteksi_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url']) && isset($_SESSION['user_id'])) {
    $url = trim($_POST['url']);
    if ($url) {
        // Cek apakah shell_exec tersedia
        if (function_exists('shell_exec') && !in_array('shell_exec', explode(',', ini_get('disable_functions')))) {
            // Gunakan shell_exec jika tersedia
            $output = shell_exec("python phishing_detection.py " . escapeshellarg($url) . " detailed");
            if (preg_match('/({.*})/s', $output, $matches)) {
                $deteksi_detail = json_decode($matches[1], true);
            } else {
                $deteksi_detail = null;
            }
        } else {
            // Fallback: Gunakan cURL untuk API endpoint
            $api_url = 'http://localhost:5000/detect'; // Untuk testing local
            // $api_url = 'https://api.phishingdetect.site/detect'; // Untuk production
            $post_data = json_encode(['url' => $url, 'detailed' => true]);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $api_url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Content-Length: ' . strlen($post_data)
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
                         if ($http_code === 200 && $response) {
                 $deteksi_detail = json_decode($response, true);
             } else {
                 // Debug information
                 $debug_info = "HTTP Code: $http_code, Response: " . substr($response, 0, 200);
                 error_log("API Debug: " . $debug_info);
                 
                 // Fallback: Simulasi hasil sederhana
                 $deteksi_detail = [
                     'final_result' => 'Tidak dapat mendeteksi (server offline)',
                     'ml_prediction' => 'Tidak tersedia - HTTP Code: ' . $http_code,
                     'content_analysis' => 'Tidak tersedia - Response: ' . substr($response, 0, 100),
                     'features' => [],
                     'explanation' => 'Sistem deteksi sedang dalam maintenance. Silakan coba lagi nanti. Debug: ' . $debug_info
                 ];
             }
        }
        
        if (!$deteksi_detail) {
            $deteksi_error = 'Terjadi error saat memproses deteksi. Silakan coba lagi atau hubungi administrator.';
        }
        $deteksi_hasil = $deteksi_detail['final_result'] ?? '';
        $username = $_SESSION['username'];
        try {
            $stmt = $conn->prepare("INSERT INTO riwayat (username, url, hasil) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param('sss', $username, $url, $deteksi_hasil);
                $stmt->execute();
            }
        } catch (Exception $e) {
            error_log("Error inserting riwayat: " . $e->getMessage());
            // Lanjutkan tanpa menyimpan ke database
        }
    }
}

// Ambil riwayat user jika login
$riwayat = [];
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    try {
        $stmt = $conn->prepare("SELECT * FROM riwayat WHERE username=? ORDER BY waktu DESC LIMIT 5");
        if ($stmt) {
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $result = $stmt->get_result();
            while($row = $result->fetch_assoc()) {
                $riwayat[] = $row;
            }
        }
    } catch (Exception $e) {
        // Jika ada error database, set riwayat kosong
        $riwayat = [];
        error_log("Database error in index.php: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Link Phishing Detection</title>
    <link rel="stylesheet" href="static/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <script src="static/theme.js"></script>
    <style>
    /* Style khusus untuk subtitle di halaman deteksi */
    header p.login-subtitle {
        color: #fff !important;
        text-shadow: 0 2px 8px rgba(0,0,0,0.3);
        background: rgba(0,0,0,0.2);
        padding: 8px 16px;
        border-radius: 20px;
        display: inline-block;
        backdrop-filter: blur(10px);
        font-weight: 500;
    }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <header class="animate__animated animate__fadeIn">
      <h1>Link Phishing Detection</h1>
      <p class="login-subtitle">Menganalisis Link untuk mendeteksi potensi phishing</p>
    </header>
    <div class="container">
      <div class="card animate__animated animate__fadeInUp">
        <h2>Check URL</h2>
        <div class="form-group">
          <form method="post" action="">
            <label for="url-input">Enter URL to analyze:</label>
            <div class="input-group">
              <input type="text" id="url-input" name="url" placeholder="https://example.com" class="pulse-focus" required />
              <button type="submit" class="btn-animated">Analyze</button>
            </div>
          </form>
        </div>
        <div class="result-section" id="result-section" style="display:<?= $deteksi_hasil || $deteksi_error ? 'block' : 'none' ?>;margin-top:20px;">
          <h3>Analysis Result:</h3>
          <?php if ($deteksi_error): ?>
            <div class="result-box phishing animate__animated animate__fadeIn">
              <div class="result-text" id="result-text" style="font-size:1.05em;">
                <?= $deteksi_error ?>
              </div>
            </div>
          <?php elseif ($deteksi_detail):
            $is_safe = (stripos($deteksi_detail['final_result'], 'bukan website phishing') !== false);
          ?>
          <div class="result-box <?= $is_safe ? 'safe' : 'phishing' ?> animate__animated animate__fadeIn">
            <div class="result-text" id="result-text" style="font-size:1.15em;font-weight:bold;">
              <?= htmlspecialchars($deteksi_detail['final_result']) ?>
            </div>
            <div class="result-icon" id="result-icon">
              <?= $is_safe ? '✓' : '⚠' ?>
            </div>
          </div>
          <div class="result-detail" style="margin-top:18px;">
            <div style="margin-bottom:10px;"><b>Penjelasan Model ML:</b><br>
              <?= htmlspecialchars($deteksi_detail['ml_prediction'] ?? '-') ?>
            </div>
            <div><b>Penjelasan Content Analysis:</b><br>
              <?php
                if (isset($deteksi_detail['content_analysis']['message'])) {
                  echo htmlspecialchars($deteksi_detail['content_analysis']['message']);
                }
                if (isset($deteksi_detail['content_analysis']['reasons']) && is_array($deteksi_detail['content_analysis']['reasons'])) {
                  echo '<ul style="margin:8px 0 0 18px;">';
                  foreach ($deteksi_detail['content_analysis']['reasons'] as $reason) {
                    echo '<li>' . htmlspecialchars($reason) . '</li>';
                  }
                  echo '</ul>';
                }
              ?>
            </div>
          </div>
          <?php else: ?>
          <div class="result-box animate__animated animate__fadeIn">
            <div class="result-text" id="result-text">
              Hasil akan muncul disini
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
      <div class="card history-section animate__animated animate__fadeInUp animate__delay-1s">
        <h2>Recent Checks</h2>
        <ul class="history-list" id="history-list">
          <?php if ($riwayat): foreach ($riwayat as $item): ?>
            <?php
              $hasil = strtolower($item['hasil']);
              $is_safe = strpos($hasil, 'bukan website phishing') !== false;
              $is_phishing = strpos($hasil, 'phishing') !== false && !$is_safe;
              $badge_class = $is_safe ? 'safe' : ($is_phishing ? 'phishing' : 'neutral');
            ?>
            <li class="history-item animate__animated animate__fadeInRight">
              <span class="history-url"><?= htmlspecialchars($item['url']) ?></span>
              <span class="history-result <?= $badge_class ?>">
                <?= htmlspecialchars($item['hasil']) ?>
              </span>
            </li>
          <?php endforeach; else: ?>
            <li class="history-item">No history yet</li>
          <?php endif; ?>
        </ul>
      </div>
      <div class="card info-section animate__animated animate__fadeInUp animate__delay-2s">
        <h2>Bagaimana Cara Website ini Mendeteksi Phishing</h2>
        <p>
          Sistem ini menganalisis URLs menggunakan beberapa fitur untuk
          mengidentifikasi potensi upaya phishing.
        </p>
        <div class="feature-grid">
          <div class="feature-card hover-effect">
            <div class="feature-title">Panjang URL</div>
            <p>
              Phishing URL yang panjang biasanya untuk menutupi hal yang
              mencurigakan di nama domain.
            </p>
          </div>
          <div class="feature-card hover-effect">
            <div class="feature-title">Karakter Mencurigakan</div>
            <p>
              Special karakter seperti '@' dan '-' yang biasa dipakai untuk
              mengelabui URLs.
            </p>
          </div>
          <div class="feature-card hover-effect">
            <div class="feature-title">Penggunaan IP Address</div>
            <p>
              Situs web yang sah jarang menggunakan alamat IP di URL mereka.
            </p>
          </div>
          <div class="feature-card hover-effect">
            <div class="feature-title">Umur Domain</div>
            <p>Domain phishing biasanya baru saja didaftarkan.</p>
          </div>
          <div class="feature-card hover-effect">
            <div class="feature-title">SSL Sertifikasi</div>
            <p>Situs yang sah menerapkan koneksi aman (HTTPS).</p>
          </div>
          <div class="feature-card hover-effect">
            <div class="feature-title">Jumlah Subdomain</div>
            <p>
              Beberapa subdomain dapat menjadi tanda adanya percobaan phishing.
            </p>
          </div>
        </div>
      </div>
    </div>
    <footer>
      <div class="footer-content">
        <div class="creator-info animate__animated animate__fadeIn">
          <p>Created by <span class="author-name">Laurensius Alessandro</span></p>
        </div>
        <div class="social-icons animate__animated animate__fadeIn">
          <a href="https://instagram.com/laurenaldr" target="_blank" class="social-icon">
            <i class="fab fa-instagram"></i>
          </a>
          <a href="mailto:laurensandro9@gmail.com" class="social-icon">
            <i class="far fa-envelope"></i>
          </a>
          <a href="https://github.com/Laurenwork" target="_blank" class="social-icon">
            <i class="fab fa-github"></i>
          </a>
          <a href="https://www.linkedin.com/in/laurensius-alessandro/" target="_blank" class="social-icon">
            <i class="fab fa-linkedin"></i>
          </a>
        </div>
        <p class="copyright">&copy; 2025 URL Phishing Detection. All rights reserved.</p>
      </div>
    </footer>
</body>
</html> 