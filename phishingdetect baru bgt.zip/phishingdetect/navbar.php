<nav class="main-navbar">
  <div class="navbar-content">
    <div class="navbar-logo">
      <i class="fas fa-shield-alt"></i> <span>PhishingDetect</span>
    </div>
    <ul>
      <li class="<?= basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : '' ?>"><a href="about.php">Home</a></li>
      <li class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>"><a href="index.php">Detect</a></li>
      <li class="<?= basename($_SERVER['PHP_SELF']) == 'riwayat.php' ? 'active' : '' ?>"><a href="riwayat.php">Riwayat</a></li>
      <?php if (isset($_SESSION['username'])): ?>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
          <li class="<?= basename($_SERVER['PHP_SELF']) == 'admin.php' ? 'active' : '' ?>"><a href="admin.php">Admin Panel</a></li>
        <?php endif; ?>
        <li style="position:relative;">
          <a href="#" id="logout-link">Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a>
          <div id="logout-confirm" style="display:none;position:absolute;top:110%;left:0;z-index:1000;background:var(--bg-card);border:1.5px solid var(--border-color);box-shadow:0 2px 8px rgba(0,0,0,0.12);padding:16px 18px;border-radius:10px;min-width:180px;text-align:center;">
            <div style="margin-bottom:10px;color:var(--text-primary);font-weight:500;">Yakin ingin keluar?</div>
            <button id="logout-yes" class="btn-animated" style="margin-right:10px;">Ya</button>
            <button id="logout-no" class="btn-animated btn-secondary">Tidak</button>
          </div>
        </li>
      <?php else: ?>
        <li class="<?= basename($_SERVER['PHP_SELF']) == 'auth.php' ? 'active' : '' ?>"><a href="auth.php">Login</a></li>
      <?php endif; ?>
      <li class="theme-toggle">
        <button id="theme-toggle-btn" class="theme-btn" type="button" title="Toggle Dark/Light Mode">
          <i class="fas fa-sun" id="theme-icon"></i>
        </button>
      </li>
    </ul>
  </div>
</nav>

<script src="static/theme.js"></script>
<script>
// Konfirmasi interaktif logout di bawah tombol
const logoutLink = document.getElementById('logout-link');
const logoutConfirm = document.getElementById('logout-confirm');
const logoutYes = document.getElementById('logout-yes');
const logoutNo = document.getElementById('logout-no');

if (logoutLink && logoutConfirm) {
  logoutLink.addEventListener('click', function(e) {
    e.preventDefault();
    logoutConfirm.style.display = 'block';
  });
}
if (logoutNo) {
  logoutNo.addEventListener('click', function() {
    logoutConfirm.style.display = 'none';
  });
}
if (logoutYes) {
  logoutYes.addEventListener('click', function() {
    window.location.href = 'logout.php?redirect=about.php';
  });
}
// Klik di luar box konfirmasi untuk menutup
window.addEventListener('click', function(e) {
  if (logoutConfirm && logoutConfirm.style.display === 'block') {
    if (!logoutConfirm.contains(e.target) && e.target !== logoutLink) {
      logoutConfirm.style.display = 'none';
    }
  }
});
</script> 