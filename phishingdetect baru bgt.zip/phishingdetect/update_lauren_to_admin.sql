-- File untuk mengubah role Lauren menjadi admin
USE phishingdetect;

-- Update role Lauren menjadi admin
UPDATE users 
SET role = 'admin' 
WHERE username = 'Lauren' AND email = 'laurensandro9@gmail.com';

-- Tampilkan hasil update
SELECT id, username, email, role FROM users WHERE username = 'Lauren';

-- Tampilkan semua admin yang ada
SELECT id, username, email, role FROM users WHERE role = 'admin'; 