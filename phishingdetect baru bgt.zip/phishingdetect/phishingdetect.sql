-- SQL untuk aplikasi Phishingdetect
CREATE DATABASE IF NOT EXISTS phishingdetect;
USE phishingdetect;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS riwayat (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  url VARCHAR(255),
  hasil VARCHAR(50),
  waktu DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Jika tabel users sudah ada tanpa kolom email, jalankan query ini:
-- ALTER TABLE users ADD COLUMN email VARCHAR(100) NOT NULL DEFAULT 'user@example.com' AFTER username;

 