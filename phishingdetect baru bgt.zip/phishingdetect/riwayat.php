<?php
session_start();
$isGuest = !isset($_SESSION['username']);
require 'config.php';
$riwayat = null;
if (!$isGuest) {
    $username = $_SESSION['username'];
    try {
        $stmt = $conn->prepare("SELECT * FROM riwayat WHERE username=? ORDER BY waktu DESC");
        if ($stmt) {
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $riwayat = $stmt->get_result();
        }
    } catch (Exception $e) {
        error_log("Database error in riwayat.php: " . $e->getMessage());
        $riwayat = null;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat - PhishingDetect</title>
    <link rel="stylesheet" href="static/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <script src="static/theme.js"></script>
    <style>
    .container { min-height: 80vh; }
    
    /* Style khusus untuk subtitle di halaman riwayat */
    header p.login-subtitle {
        color: #fff !important;
        text-shadow: 0 2px 8px rgba(0,0,0,0.3);
        background: rgba(0,0,0,0.2);
        padding: 8px 16px;
        border-radius: 20px;
        display: inline-block;
        backdrop-filter: blur(10px);
        font-weight: 500;
    }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <header class="animate__animated animate__fadeIn">
        <h1>Riwayat Pencarian</h1>
        <p class="login-subtitle">
            <?php if ($isGuest): ?>
                Belum ada riwayat. Silakan login atau registrasi terlebih dahulu untuk melihat riwayat Anda.
            <?php else: ?>
                Lihat semua riwayat deteksi phishing yang telah Anda lakukan
            <?php endif; ?>
        </p>
    </header>
<div class="container">
    <div class="card animate__animated animate__fadeInUp" style="max-width:700px;margin:40px auto;">
        <h2 style="color:#2563eb;text-align:center;margin-bottom:18px;">
            <i class="fas fa-history"></i> Riwayat Pencarian Anda
        </h2>
        <?php if ($isGuest): ?>
            <div style="text-align:center;padding:20px 16px;">
                <div style="font-size:64px;color:#2563eb;margin-bottom:8px;">
                    <i class="fas fa-user-clock"></i>
                </div>
                <p style="color:#555;margin:8px 0 16px;">Anda belum login. Masuk atau buat akun untuk menyimpan dan melihat riwayat deteksi.</p>
                <input type="text" placeholder="Riwayat akan tampil di sini setelah login" disabled style="width:90%;max-width:500px;padding:12px 14px;border:1.5px solid #e3e6ef;border-radius:10px;background:#f6f7fb;color:#999;margin-bottom:14px;">
                <div>
                    <a href="auth.php" class="btn-animated" style="margin-right:8px;">Login</a>
                    <a href="auth.php#register" class="btn-animated btn-secondary">Registrasi</a>
                </div>
            </div>
        <?php else: ?>
        <ul class="history-list" id="history-list">
            <?php if($riwayat && $riwayat->num_rows > 0): while($row = $riwayat->fetch_assoc()): ?>
                <?php
                  $hasil = strtolower($row['hasil']);
                  $is_safe = strpos($hasil, 'bukan website phishing') !== false;
                  $is_phishing = strpos($hasil, 'phishing') !== false && !$is_safe;
                  $badge_class = $is_safe ? 'safe' : ($is_phishing ? 'phishing' : 'neutral');
                ?>
                <li class="history-item animate__animated animate__fadeInRight">
                    <span class="history-url" style="max-width:320px;overflow-wrap:anywhere;display:inline-block;">
                        <?= htmlspecialchars($row['url']) ?>
                        <button class="copy-btn" title="Copy URL" onclick="copyToClipboard('<?= htmlspecialchars($row['url']) ?>', this)"><i class="fas fa-copy"></i></button>
                    </span>
                    <span class="history-result <?= $badge_class ?>">
                        <?= htmlspecialchars($row['hasil']) ?>
                    </span>
                    <span style="font-size:0.95em;color:#888;margin-left:12px;">
                        <?= date('d M Y H:i', strtotime($row['waktu'])) ?>
                    </span>
                </li>
            <?php endwhile; else: ?>
                <li class="history-item">Belum ada riwayat pencarian.</li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>
        <div id="copy-toast" class="copy-toast" style="display:none;">URL copied!</div>
    </div>
</div>
<script>
function copyToClipboard(text, btn) {
    navigator.clipboard.writeText(text).then(function() {
        const toast = document.getElementById('copy-toast');
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 1200);
        btn.classList.add('copied');
        setTimeout(() => { btn.classList.remove('copied'); }, 800);
    });
}
// Tooltip
const results = document.querySelectorAll('.history-result');
results.forEach(function(el) {
    el.addEventListener('mouseenter', function() {
        let tip = document.createElement('div');
        tip.className = 'tooltip';
        tip.innerText = el.getAttribute('data-tooltip');
        document.body.appendChild(tip);
        const rect = el.getBoundingClientRect();
        tip.style.left = (rect.left + window.scrollX + rect.width/2 - tip.offsetWidth/2) + 'px';
        tip.style.top = (rect.top + window.scrollY - tip.offsetHeight - 8) + 'px';
        el._tip = tip;
    });
    el.addEventListener('mouseleave', function() {
        if (el._tip) document.body.removeChild(el._tip);
            });
});
</script>

<footer>
    <div class="footer-content">
        <div class="creator-info animate__animated animate__fadeIn">
            <p>Created by <span class="author-name">Laurensius Alessandro</span></p>
        </div>
        <div class="social-icons animate__animated animate__fadeIn">
            <a href="https://instagram.com/laurenaldr" target="_blank" class="social-icon">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:laurensandro9@gmail.com" class="social-icon">
                <i class="far fa-envelope"></i>
            </a>
            <a href="https://github.com/Laurenwork" target="_blank" class="social-icon">
                <i class="fab fa-github"></i>
            </a>
            <a href="https://www.linkedin.com/in/laurensius-alessandro/" target="_blank" class="social-icon">
                <i class="fab fa-linkedin"></i>
            </a>
        </div>
        <p class="copyright">&copy; 2025 URL Phishing Detection. All rights reserved.</p>
    </div>
</footer>
</body>
</html> 