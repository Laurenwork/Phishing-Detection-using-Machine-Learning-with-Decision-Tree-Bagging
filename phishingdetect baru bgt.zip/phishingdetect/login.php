<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}
require 'config.php';
$msg = '';
$flash = '';
if (isset($_SESSION['flash_msg'])) {
    $flash = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];
    $result = $conn->query("SELECT * FROM users WHERE username='$username'");
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header('Location: index.php');
            exit();
        } else {
            $msg = 'Password salah!';
        }
    } else {
        $msg = 'Username tidak ditemukan!';
    }
}
?>
<?php include 'navbar.php'; ?>
<link rel="stylesheet" href="static/style.css">
<div class="container">
    <div class="card animate__animated animate__fadeInUp" style="max-width:400px;margin:40px auto;">
        <h2 style="text-align:center;color:#2563eb;"><i class="fas fa-sign-in-alt"></i> Login</h2>
        <?php if ($flash): ?>
            <div class="result-box phishing animate__animated animate__fadeInDown" style="margin-bottom:16px;"> <?= htmlspecialchars($flash) ?> </div>
        <?php endif; ?>
        <?php if ($msg): ?>
            <div class="result-box phishing" style="margin-bottom:16px;"> <?= htmlspecialchars($msg) ?> </div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> Username</label>
                <input type="text" name="username" id="username" class="pulse-focus" required style="width:100%;margin-bottom:12px;">
            </div>
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" id="password" class="pulse-focus" required style="width:100%;margin-bottom:18px;">
            </div>
            <button type="submit" class="btn-animated" style="width:100%;">Login</button>
        </form>
        <p style="text-align:center;margin-top:18px;">Belum punya akun? <a href="register.php" style="color:#2563eb;font-weight:bold;">Daftar</a></p>
    </div>
</div> 