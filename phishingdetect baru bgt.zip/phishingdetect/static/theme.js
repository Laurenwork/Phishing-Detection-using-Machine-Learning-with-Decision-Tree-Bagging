// Theme management for PhishingDetect
console.log('Theme.js loaded');

class ThemeManager {
  constructor() {
        console.log('ThemeManager constructor called');
    this.body = document.body;
        this.themeIcon = document.getElementById('theme-icon');
        this.themeBtn = document.getElementById('theme-toggle-btn');
        
        console.log('Body element:', this.body);
        console.log('Theme icon element:', this.themeIcon);
        console.log('Theme button element:', this.themeBtn);
        
    this.init();
  }

  init() {
        console.log('Initializing theme manager...');
        
    // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        console.log('Saved theme from localStorage:', savedTheme);
        
    this.setTheme(savedTheme);

    // Add event listener for theme toggle button
        if (this.themeBtn) {
            console.log('Adding click event listener to theme button');
            
            // Remove any existing event listeners
            this.themeBtn.removeEventListener('click', this.handleThemeClick);
            
            // Add new event listener
            this.themeBtn.addEventListener('click', this.handleThemeClick.bind(this));
            
            // Also add mousedown to prevent any default behavior
            this.themeBtn.addEventListener('mousedown', (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
            
        } else {
            console.error('Theme button not found!');
        }
        
        console.log('Theme manager initialized with theme:', savedTheme);
    }

    handleThemeClick(e) {
        console.log('Theme button clicked!');
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        
        // Prevent form submission if inside a form
        if (e.target.closest('form')) {
            e.preventDefault();
        }
        
        this.toggleTheme();
        return false;
    }

    setTheme(theme) {
        console.log('Setting theme to:', theme);
        
        if (!this.body) {
            console.error('Body element not found!');
            return;
        }
        
        this.body.setAttribute('data-theme', theme);
        
        if (this.themeIcon) {
            this.themeIcon.className = theme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
            console.log('Theme icon updated to:', this.themeIcon.className);
        } else {
            console.error('Theme icon not found!');
        }
        
        localStorage.setItem('theme', theme);
        console.log('Theme saved to localStorage:', theme);
        
        // Force a repaint
        this.body.style.transition = 'all 0.3s ease';
    setTimeout(() => {
            this.body.style.transition = '';
    }, 300);
  }

    toggleTheme() {
        console.log('Toggle theme called');
        const currentTheme = this.body.getAttribute('data-theme') || 'light';
        console.log('Current theme:', currentTheme);
        
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        console.log('New theme will be:', newTheme);
        
        this.setTheme(newTheme);
        
        console.log('Theme toggle completed');
    }

  getCurrentTheme() {
        return this.body.getAttribute('data-theme') || 'light';
  }
}

// Initialize theme manager when DOM is ready
function initializeThemeManager() {
    console.log('Initializing theme manager...');
    try {
    window.themeManager = new ThemeManager();
        console.log('Theme manager created successfully');
    } catch (error) {
        console.error('Error creating theme manager:', error);
    }
}

if (document.readyState === 'loading') {
    console.log('DOM still loading, waiting for DOMContentLoaded');
    document.addEventListener('DOMContentLoaded', initializeThemeManager);
} else {
    console.log('DOM already loaded, initializing immediately');
    initializeThemeManager();
}

// Global function for backward compatibility
function toggleTheme() {
    console.log('Global toggleTheme function called');
  if (window.themeManager) {
    window.themeManager.toggleTheme();
  } else {
        console.error('Theme manager not initialized');
    }
}

// Debug: Check if everything loaded
setTimeout(() => {
    console.log('=== THEME DEBUG INFO ===');
    console.log('Theme manager exists:', typeof window.themeManager !== 'undefined');
    console.log('Current theme:', document.body.getAttribute('data-theme'));
    console.log('LocalStorage theme:', localStorage.getItem('theme'));
    console.log('Theme button exists:', !!document.getElementById('theme-toggle-btn'));
    console.log('Theme icon exists:', !!document.getElementById('theme-icon'));
    console.log('========================');
}, 1000);
